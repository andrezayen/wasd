# Testes

## Automáticos (`./gradlew test`) — escritos, ainda não executados
ControlStateManager (pressionar/soltar, W+D, W+A, S+A, S+D, 3 dedos, mesmo botão com 2 dedos, deslizar, releaseAll, exceção do backend) · JoystickPlanner/TouchTargets · RunStateMachine · ControlsLayout · EditorModel (mover/adicionar/duplicar/excluir/sobreposição) · Presets e ProfileResolver · ProfileJson (ida e volta, inválido, schema, valores fora da faixa) · KeyCodes · CompositeInputBackend.

## Manuais (precisam de aparelho)
Marque cada item e anote Android/modelo/modo de entrada.
1. Sobreposição: botões aparecem sobre o jogo; fora deles o toque chega ao jogo.
2. W, depois W+D, W+A, S+A, S+D, W+A+D; soltar na ordem inversa; nada fica preso.
3. Segurar W e tocar SPACE (dedos diferentes); soltar W primeiro.
4. Rotacionar com W pressionado → solta; layout da outra orientação carrega.
5. Bloquear a tela com botão pressionado → solta.
6. Desligar o serviço de acessibilidade com W pressionado → solta.
7. Sair do jogo (Home) com botão pressionado → solta; testar Configurações → "Ao sair do jogo".
8. Matar o app pelos recentes → overlay some e o root solta as teclas.
9. PARAR (app, botão flutuante, notificação) → tudo solto e overlay removido.
10. Editor: arrastar, +Botão, duplicar, excluir, grade, Salvar, Cancelar; aviso de sobreposição.
11. Perfis: renomear, textos, preset, restaurar, exportar, importar, excluir; arquivo inválido mostra erro.
12. Modo sem root: pressione botões e veja o contador "Gestos cancelados" no Diagnóstico.
13. Modo root: teclas reais num app que mostra teclas; toques no joystick do jogo.
