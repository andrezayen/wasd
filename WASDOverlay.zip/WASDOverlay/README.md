# WASD Overlay

## Atualização (v0.2.0)
- **Sem root, com teclas reais:** novo acesso privilegiado via **Shizuku** (app gratuito; inicie-o por depuração sem fio, sem computador). Escolha em Configurações → Método de entrada (teclas reais ou toques injetados) e Origem (Automático = Shizuku e, se não der, root). Botão "Autorizar o Shizuku" nas Configurações. Root (`su`) continua opcional.
- Botões personalizados (C1–C4) ganham tecla real escolhida em Perfis → Teclas reais dos botões personalizados.
- Cada botão vira uma janela própria: o espaço entre botões entrega o toque ao jogo; deslizar entre botões continua funcionando.
- Editor: estilo por botão (transparência, borda, cantos, texto), escala geral, "Capturar" (toque o ponto exato do jogo), botão flutuante com troca de perfil.
- Vibração com intensidade; idiomas: **inglês e português** (padrão = inglês; outros idiomas ainda não traduzidos — copie `/res/values/strings.xml` para `values-xx/` e traduza).
- Android 16: compileSdk/targetSdk 36 (AGP 8.11.1, Gradle 8.14.3, Kotlin 2.1.20). O app já usa edge-to-edge e não restringe orientação; o resto do comportamento do Android 16 continua **não verificado em aparelho**.
- Assinatura de release: copie `keystore.properties.example` para `keystore.properties`. Licença: MIT (`LICENSE`).

Controles virtuais flutuantes (W A S D e mais 26 botões) sobre jogos no Android, com perfis por jogo, editor, multi-touch e três métodos de entrada. O nome do app fica só em `app/src/main/res/values/strings.xml` (`app_name`).

> **Estado honesto:** este projeto foi escrito e revisado estaticamente (referências de recursos, imports, parênteses, testes unitários escritos). **Não foi compilado nem executado** — o ambiente de geração não tinha Android SDK, Gradle nem internet. Nada aqui foi verificado em hardware real. Abra no Android Studio, sincronize e me envie os erros, se houver.

## A limitação fundamental (pesquisada)
1. **Teclas reais sem root: impossível.** Injetar `KeyEvent`/`MotionEvent` em outro app usa `InputManager.injectInputEvent`, que exige a permissão `INJECT_EVENTS` (só sistema/shell/root). `AccessibilityService` só despacha gestos de toque; `InputMethodService` só escreve no campo de texto em foco; `BluetoothHidDevice` é teclado de *outro* aparelho.
2. **Gestos de acessibilidade são cancelados por toques reais.** No código do AOSP (`MotionEventInjector`), qualquer `MotionEvent` real que chega cancela o gesto injetado em andamento. Como o botão do overlay é tocado com o dedo real, o modo sem root sofre cancelamentos (o app re-despacha em ~8 ms e conta os cancelamentos em *Diagnóstico*). Pode funcionar parcialmente; não é confiável.
3. **Por isso existem os modos root (opcionais, nunca obrigatórios):** o app lança, via `su`, um processo auxiliar (`app_process`, a mesma técnica do scrcpy) que injeta teclas ou toques de verdade pelo método oculto `InputManager.injectInputEvent` (Android 14+: `InputManagerGlobal`), via reflexão. Isso não passa pelo filtro de acessibilidade e não é cancelado por toques reais.

## Métodos de entrada (Configurações → Método de entrada)
| Modo | Root | O que faz | Situação |
|---|---|---|---|
| Acessibilidade (padrão) | não | W/A/S/D deslocam um "dedo" no joystick do jogo; demais botões seguram um toque num ponto calibrado; um dedo simulado por botão (até `getMaxStrokeCount()`, geralmente 10) | IMPLEMENTADO, não verificado; sujeito a cancelamentos |
| Root: teclas reais | sim | `KeyEvent` down/up reais (W A S D SPACE SHIFT CTRL ALT TAB ESC ENTER E Q R F 0-9). CUSTOM1-4 não têm tecla → caem para a acessibilidade | IMPLEMENTADO, não verificado |
| Root: toques | sim | `MotionEvent` multi-ponteiro (joystick + pontos), sem encadear gestos | IMPLEMENTADO, não verificado |
Se o `su` falhar ou morrer, o app volta sozinho para a acessibilidade. Jogos que só aceitam gamepad, ou com proteção contra gestos/`FLAG_SECURE`/anti-cheat, podem ignorar a entrada.

## Funcionalidades
- Overlay sobre outros apps (`TYPE_APPLICATION_OVERLAY`), janela só do tamanho dos botões, multi-touch por ID de ponteiro, deslizar entre botões, feedback instantâneo, vibração/som opcionais (desligados por padrão).
- 30 ações: W A S D SPACE SHIFT CTRL ALT TAB ESC ENTER E Q R F 0-9 e CUSTOM1-4.
- Editor em tela cheia sobre o jogo: arrastar botões, `+ Botão`, duplicar, excluir, grade com encaixe (16 dp), tamanho, raio do joystick, marcadores laranja (ponto de toque de cada ação no jogo), aviso quando o joystick do jogo fica sob os botões, Salvar/Cancelar. Texto dos botões: Perfis → Editar textos.
- Perfis por jogo **e por orientação** (retrato/paisagem), presets (WASD básico, +Space, +Space+Shift, FPS, MOBA), perfil padrão criado na instalação, restaurar layout/todos (com confirmação), importar/exportar JSON versionado (`schemaVersion: 1`), carregamento automático do perfil ao abrir o jogo (nome do pacote da janela, via acessibilidade).
- Botão flutuante (Ocultar/Mostrar, Editar, **PARAR**), notificação com Parar e Mostrar/Ocultar, máquina de estados (STOPPED/STARTING/RUNNING/PAUSED/STOPPING/ERROR), onboarding, ajuda, diagnóstico, tema claro/escuro/sistema, edge-to-edge.
- Segurança: `releaseAllControls()` em ACTION_CANCEL, overlay removido, tela desligada, rotação, parar serviço, serviço de acessibilidade desligado, exceção do backend, saída do jogo (configurável) e saída do processo root (solta tudo).

## Requisitos e versões
minSdk 29 (Android 10) · targetSdk/compileSdk 36 · AGP 8.11.1 · Gradle 8.14.3 · Kotlin 2.1.20 · Shizuku API 13.1.5 · Java 17 · core-ktx 1.13.1, appcompat 1.7.0, material 1.12.0 · testes: JUnit 4.13.2, org.json 20240303. Sem INTERNET. Android 16 (API 36): não verificado.

## Permissões
`SYSTEM_ALERT_WINDOW` (manual), serviço de acessibilidade (manual; só gestos e nome do pacote em primeiro plano; **não** lê conteúdo da tela), `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE` (serviço do overlay), `POST_NOTIFICATIONS`. Root: só se o usuário escolher o modo root.

## Compilar, testar, instalar
1. Abra a pasta no Android Studio e sincronize. Sem `gradle-wrapper.jar`, rode `gradle wrapper --gradle-version 8.14.3` uma vez.
2. `./gradlew test` (testes unitários) · `./gradlew assembleDebug` (APK em `app/build/outputs/apk/debug`) · `./gradlew bundleRelease` (AAB; configure assinatura).
3. Instale o APK. Abra o app → onboarding → **Conceder sobreposição** → **Abrir acessibilidade** (Android 13+: se estiver bloqueado, Informações do app → ⋮ → *Permitir configurações restritas*).
4. **1. Escolher jogo → 2. Posicionar WASD e joystick** (abre o jogo com o editor) → **Salvar** → **3. Iniciar e jogar**. Para root: Configurações → Método de entrada.

## Arquitetura
`model/` (ações, perfis, presets, resolução de perfil — puro) · `control/` (estado dos botões, máquina de estados) · `input/` (`InputBackend`; acessibilidade, root teclas, root toques, composto; planejamento puro `TouchTargets`) · `root/` (processo auxiliar) · `overlay/` (janelas: jogo, editor, botão flutuante) · `service/` (foreground service) · `storage/` (JSON, configurações) · `ui/` (telas). **Overlay desenha; backend produz a ação** — o overlay funciona visualmente mesmo sem backend.

## Compatibilidade por versão (documentada, não testada)
10: base. 11: `<queries>` para listar apps; `maximumWindowMetrics`. 12: restrições de início de serviço em primeiro plano e de toques "não confiáveis". 13: `POST_NOTIFICATIONS`; acessibilidade de APK fora da loja exige liberar configurações restritas. 14: tipo de serviço em primeiro plano obrigatório (`specialUse`); `InputManagerGlobal` no modo root. 15: edge-to-edge obrigatório (tratado com insets).

## Problemas conhecidos / não verificado
- Tudo em hardware real; reflexão do modo root varia por ROM (algumas exigem "depuração USB (configurações de segurança)" mesmo no shell).
- Sem root, cancelamentos de gesto podem fazer o joystick "piscar".
- O overlay de jogo é uma janela única: o espaço entre botões também consome toque.
- Um preset não garante funcionar em nenhum jogo: cada marcador laranja precisa ser levado ao botão certo do jogo.
- Falta traduzir para os demais idiomas (infra de idiomas pronta).
