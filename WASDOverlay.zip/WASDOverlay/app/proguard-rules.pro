# Processos auxiliares são lançados por NOME (app_process / Shizuku): não renomear nem remover.
-keep class com.wasdoverlay.root.** { *; }
-keep class com.wasdoverlay.shizuku.** { *; }
