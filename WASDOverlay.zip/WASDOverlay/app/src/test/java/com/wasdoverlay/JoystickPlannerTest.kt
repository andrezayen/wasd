package com.wasdoverlay

import com.wasdoverlay.input.JoystickPlanner
import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.JoystickPx
import com.wasdoverlay.model.Point
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import kotlin.math.hypot

class JoystickPlannerTest {
    private val j = JoystickPx(Point(200f, 800f), 100f)

    @Test fun emptyMeansLiftFinger() = assertNull(JoystickPlanner.target(emptySet(), j))

    @Test fun wGoesUp() {
        val t = JoystickPlanner.target(setOf(ControlAction.W), j)!!
        assertEquals(200f, t.x, 0.001f); assertEquals(700f, t.y, 0.001f)
    }

    @Test fun diagonalIsNormalizedToRadius() {
        val t = JoystickPlanner.target(setOf(ControlAction.W, ControlAction.D), j)!!
        assertEquals(100f, hypot(t.x - 200f, t.y - 800f), 0.01f)
        assert(t.x > 200f && t.y < 800f)
    }

    @Test fun opposingDirectionsStayAtCenter() {
        assertEquals(j.center, JoystickPlanner.target(setOf(ControlAction.W, ControlAction.S), j))
    }
}
