package com.wasdoverlay

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.ControlSpec
import com.wasdoverlay.model.Profile
import com.wasdoverlay.overlay.ControlsLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ControlsLayoutTest {
    private fun profile(vararg c: ControlSpec) = Profile.default().copy(controls = c.toList())

    @Test fun hitTestUsesWindowCoordinates() {
        val l = ControlsLayout.compute(
            profile(ControlSpec("w", ControlAction.W, "W", 0.5f, 0.5f, 50f)), 2000, 1000, 2f,
        )!!
        assertEquals(1000f, l.bounds.left, 0.01f)
        assertEquals(ControlAction.W, l.hitTest(10f, 10f)?.spec?.action)
        assertNull(l.hitTest(150f, 150f))
    }

    @Test fun controlsAreClampedInsideScreen() {
        val l = ControlsLayout.compute(
            profile(ControlSpec("d", ControlAction.D, "D", 1.0f, 1.0f, 50f)), 2000, 1000, 2f,
        )!!
        assertEquals(1900f, l.placed[0].rect.left, 0.01f)
        assertEquals(900f, l.placed[0].rect.top, 0.01f)
    }

    @Test fun emptyProfileHasNoLayout() = assertNull(ControlsLayout.compute(profile(), 2000, 1000, 2f))

    @Test fun defaultProfileProducesLayout() =
        assertNotNull(ControlsLayout.compute(Profile.default(), 2400, 1080, 2.75f))
}
