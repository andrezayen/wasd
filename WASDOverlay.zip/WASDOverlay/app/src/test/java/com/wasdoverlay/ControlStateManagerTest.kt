package com.wasdoverlay

import com.wasdoverlay.control.ControlStateManager
import com.wasdoverlay.input.InputBackend
import com.wasdoverlay.model.ControlAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeBackend : InputBackend {
    val calls = mutableListOf<String>()
    var failOnPress = false
    override val isAvailable = true
    override fun press(action: ControlAction) {
        if (failOnPress) throw IllegalStateException("falha simulada")
        calls += "press ${action.name}"
    }
    override fun release(action: ControlAction) { calls += "release ${action.name}" }
    override fun releaseAll() { calls += "releaseAll" }
}

class ControlStateManagerTest {
    private val backend = FakeBackend()
    private val m = ControlStateManager(backend)

    @Test fun pressAndRelease() {
        m.pointerDown(0, ControlAction.W)
        assertTrue(m.isPressed(ControlAction.W))
        m.pointerUp(0)
        assertFalse(m.isPressed(ControlAction.W))
        assertEquals(listOf("press W", "release W"), backend.calls)
    }

    @Test fun multiTouchWAndD_releasingOneKeepsOther() {
        m.pointerDown(0, ControlAction.W)
        m.pointerDown(1, ControlAction.D)
        assertEquals(setOf(ControlAction.W, ControlAction.D), m.activeActions())
        m.pointerUp(0)
        assertEquals(setOf(ControlAction.D), m.activeActions())
        m.pointerUp(1)
        assertTrue(m.activeActions().isEmpty())
    }

    @Test fun allDiagonalCombinations() {
        val combos = listOf(
            ControlAction.W to ControlAction.A, ControlAction.W to ControlAction.D,
            ControlAction.S to ControlAction.A, ControlAction.S to ControlAction.D,
        )
        for ((a, b) in combos) {
            m.pointerDown(0, a); m.pointerDown(1, b)
            assertEquals(setOf(a, b), m.activeActions())
            m.pointerUp(1); m.pointerUp(0) // soltar na ordem inversa
            assertTrue(m.activeActions().isEmpty())
        }
    }

    @Test fun threeFingersWAD_thenReleaseInAnyOrder() {
        m.pointerDown(0, ControlAction.W); m.pointerDown(1, ControlAction.A); m.pointerDown(2, ControlAction.D)
        m.pointerUp(1); m.pointerUp(0)
        assertEquals(setOf(ControlAction.D), m.activeActions())
        m.pointerUp(2)
        assertTrue(m.activeActions().isEmpty())
    }

    @Test fun twoFingersSameButton_releasedOnlyWhenLastLeaves() {
        m.pointerDown(0, ControlAction.W); m.pointerDown(1, ControlAction.W)
        m.pointerUp(0)
        assertTrue(m.isPressed(ControlAction.W))
        m.pointerUp(1)
        assertFalse(m.isPressed(ControlAction.W))
        assertEquals(1, backend.calls.count { it == "press W" })
    }

    @Test fun slidingFingerSwitchesButton() {
        m.pointerDown(0, ControlAction.W)
        m.pointerMoved(0, ControlAction.D)
        assertEquals(setOf(ControlAction.D), m.activeActions())
    }

    @Test fun releaseAllControlsClearsEverything() {
        m.pointerDown(0, ControlAction.W); m.pointerDown(1, ControlAction.D)
        m.releaseAllControls()
        assertTrue(m.activeActions().isEmpty())
        assertEquals("releaseAll", backend.calls.last())
        m.pointerUp(0) // ponteiro desconhecido: ignorado sem erro
    }

    @Test fun backendExceptionReleasesAll() {
        var reported: Throwable? = null
        val mm = ControlStateManager(backend, onError = { reported = it })
        mm.pointerDown(0, ControlAction.A)
        backend.failOnPress = true
        mm.pointerDown(1, ControlAction.S)
        assertTrue(mm.activeActions().isEmpty())
        assertTrue(reported is IllegalStateException)
        assertEquals("releaseAll", backend.calls.last())
    }
}
