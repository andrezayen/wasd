package com.wasdoverlay

import com.wasdoverlay.input.CompositeInputBackend
import com.wasdoverlay.input.InputBackend
import com.wasdoverlay.input.KeyCodes
import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Profile
import com.wasdoverlay.overlay.EditorModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private class RecordingBackend(var available: Boolean = true) : InputBackend {
    val calls = mutableListOf<String>()
    override val isAvailable get() = available
    override fun press(action: ControlAction) { calls += "press ${action.name}" }
    override fun release(action: ControlAction) { calls += "release ${action.name}" }
    override fun releaseAll() { calls += "releaseAll" }
}

class EditorOpsAndBackendsTest {
    @Test fun addControlCreatesButtonAndTargetOnce() {
        val m = EditorModel(Profile.default())
        assertTrue(m.addControl(ControlAction.SPACE))
        assertFalse(m.addControl(ControlAction.SPACE)) // já existe: só seleciona
        assertEquals(1, m.profile.controls.count { it.action == ControlAction.SPACE })
        assertNotNull(m.profile.targets[ControlAction.SPACE])
    }

    @Test fun removeKeepsAtLeastOneButtonAndDropsOrphanTarget() {
        val m = EditorModel(Profile.default())
        m.addControl(ControlAction.E)
        m.select(m.profile.controls.indexOfFirst { it.action == ControlAction.E })
        assertTrue(m.removeSelected())
        assertNull(m.profile.targets[ControlAction.E])
        repeat(10) { m.select(0); m.removeSelected() }
        assertEquals(1, m.profile.controls.size)
    }

    @Test fun duplicateCustomUsesNextFreeCustom() {
        val m = EditorModel(Profile.default())
        m.addControl(ControlAction.CUSTOM1)
        assertTrue(m.duplicateSelected())
        assertTrue(m.profile.controls.any { it.action == ControlAction.CUSTOM2 })
        assertNotNull(m.profile.targets[ControlAction.CUSTOM2])
    }

    @Test fun keyCodesCoverEverythingExceptCustom() {
        for (a in ControlAction.entries) {
            if (a.name.startsWith("CUSTOM")) assertNull(KeyCodes.of(a)) else assertNotNull(KeyCodes.of(a))
        }
        assertEquals(51, KeyCodes.of(ControlAction.W))
        assertEquals(62, KeyCodes.of(ControlAction.SPACE))
    }

    @Test fun compositeRoutesToPrimaryAndReleasesOnTheSameBackend() {
        val primary = RecordingBackend()
        val fallback = RecordingBackend()
        val c = CompositeInputBackend(primary, { it != ControlAction.CUSTOM1 }, fallback)
        c.press(ControlAction.W)
        c.press(ControlAction.CUSTOM1)
        primary.available = false // root morreu com W pressionado
        c.release(ControlAction.W)
        c.release(ControlAction.CUSTOM1)
        assertEquals(listOf("press W", "release W"), primary.calls)
        assertEquals(listOf("press CUSTOM1", "release CUSTOM1"), fallback.calls)
    }

    @Test fun compositeFallsBackWhenPrimaryUnavailableAndReleaseAllHitsBoth() {
        val primary = RecordingBackend(available = false)
        val fallback = RecordingBackend()
        val c = CompositeInputBackend(primary, { true }, fallback)
        c.press(ControlAction.A)
        c.releaseAll()
        assertEquals(listOf("press A", "releaseAll"), fallback.calls)
        assertEquals(listOf("releaseAll"), primary.calls)
    }
}
