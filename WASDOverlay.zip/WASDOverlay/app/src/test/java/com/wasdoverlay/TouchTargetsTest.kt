package com.wasdoverlay

import com.wasdoverlay.input.TouchTargets
import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.JoystickPx
import com.wasdoverlay.model.Point
import com.wasdoverlay.model.TouchGeometry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TouchTargetsTest {
    private val g = TouchGeometry(
        JoystickPx(Point(200f, 800f), 100f),
        mapOf(ControlAction.SPACE to Point(2000f, 500f), ControlAction.SHIFT to Point(2100f, 300f)),
    )

    @Test fun nothingActiveMeansNoFingers() = assertTrue(TouchTargets.compute(emptySet(), g).isEmpty())

    @Test fun movementUsesOneJoystickLane() {
        val plan = TouchTargets.compute(setOf(ControlAction.W, ControlAction.D), g)
        assertEquals(setOf(TouchTargets.JOYSTICK_LANE), plan.keys)
        assertEquals(g.joystick.center, plan.getValue(TouchTargets.JOYSTICK_LANE).start)
    }

    @Test fun eachActionGetsItsOwnFingerAtItsPoint() {
        val plan = TouchTargets.compute(setOf(ControlAction.W, ControlAction.SPACE, ControlAction.SHIFT), g)
        assertEquals(setOf(TouchTargets.JOYSTICK_LANE, "SPACE", "SHIFT"), plan.keys)
        assertEquals(Point(2000f, 500f), plan.getValue("SPACE").target)
    }

    @Test fun actionWithoutCalibratedPointIsIgnored() {
        assertTrue(TouchTargets.compute(setOf(ControlAction.CUSTOM1), g).isEmpty())
    }
}
