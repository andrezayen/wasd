package com.wasdoverlay

import com.wasdoverlay.control.RunState
import com.wasdoverlay.control.RunStateMachine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RunStateMachineTest {
    @Test fun normalLifecycle() {
        val sm = RunStateMachine()
        assertTrue(sm.transition(RunState.STARTING))
        assertTrue(sm.transition(RunState.RUNNING))
        assertTrue(sm.transition(RunState.PAUSED))
        assertTrue(sm.transition(RunState.RUNNING))
        assertTrue(sm.transition(RunState.STOPPING))
        assertTrue(sm.transition(RunState.STOPPED))
    }

    @Test fun impossibleTransitionsAreRejected() {
        val sm = RunStateMachine()
        assertFalse(sm.transition(RunState.RUNNING))
        assertFalse(sm.transition(RunState.PAUSED))
        assertEquals(RunState.STOPPED, sm.state)
    }

    @Test fun listenersAreNotifiedAndForceStopWorks() {
        val sm = RunStateMachine()
        val seen = mutableListOf<RunState>()
        sm.addListener { seen += it }
        sm.transition(RunState.STARTING); sm.transition(RunState.ERROR); sm.forceStopped()
        assertEquals(listOf(RunState.STARTING, RunState.ERROR, RunState.STOPPED), seen)
    }
}
