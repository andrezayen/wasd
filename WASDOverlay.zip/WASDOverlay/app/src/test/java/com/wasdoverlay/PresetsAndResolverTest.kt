package com.wasdoverlay

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.model.Preset
import com.wasdoverlay.model.Presets
import com.wasdoverlay.model.Profile
import com.wasdoverlay.model.ProfileResolver
import com.wasdoverlay.overlay.EditorModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PresetsAndResolverTest {
    @Test fun everyPresetHasWasdUniqueIdsAndTargetsForExtras() {
        for (o in listOf(Orientation.LANDSCAPE, Orientation.PORTRAIT)) {
            for (preset in Preset.entries) {
                val p = Presets.build(preset, "pkg", "Nome", o)
                assertTrue(p.controls.map { it.action }.containsAll(ControlAction.entries.filter { a -> a.isMovement }))
                assertEquals(p.controls.size, p.controls.map { it.id }.toSet().size)
                assertEquals(preset.extras.toSet(), p.targets.keys)
                assertFalse(EditorModel(p).joystickOverlapsControls(2400, 1080, 2.75f) && o == Orientation.LANDSCAPE)
            }
        }
    }

    @Test fun resolverPrefersExactMatchElseBuildsDefaultForOrientation() {
        val land = Presets.build(Preset.FPS, "pkg", "Meu Jogo", Orientation.LANDSCAPE)
        val found = ProfileResolver.resolve(listOf(land), "pkg", Orientation.LANDSCAPE)
        assertEquals(land, found)
        val portrait = ProfileResolver.resolve(listOf(land), "pkg", Orientation.PORTRAIT)
        assertEquals("Meu Jogo", portrait.name)
        assertEquals(Orientation.PORTRAIT, portrait.orientation)
        assertEquals(Profile.idFor("pkg", Orientation.PORTRAIT), portrait.id)
    }

    @Test fun resolverWithoutGameReturnsDefaultProfile() {
        val p = ProfileResolver.resolve(emptyList(), null, Orientation.LANDSCAPE)
        assertEquals("default|landscape", p.id)
        assertEquals(4, p.controls.size)
    }
}
