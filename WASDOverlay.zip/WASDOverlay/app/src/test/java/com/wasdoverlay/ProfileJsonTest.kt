package com.wasdoverlay

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.model.Preset
import com.wasdoverlay.model.Presets
import com.wasdoverlay.model.Profile
import com.wasdoverlay.storage.ProfileJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileJsonTest {
    @Test fun roundTripKeepsEverything() {
        val original = listOf(
            Profile.default(),
            Presets.build(Preset.FPS, "com.exemplo.jogo", "Jogo", Orientation.PORTRAIT),
        )
        val parsed = ProfileJson.fromJson(ProfileJson.toJson(original))
        assertNotNull(parsed)
        assertEquals(original.map { it.id }, parsed!!.map { it.id })
        assertEquals(Orientation.PORTRAIT, parsed[1].orientation)
        assertEquals("com.exemplo.jogo", parsed[1].packageName)
        assertEquals(original[1].controls.size, parsed[1].controls.size)
        assertEquals(original[1].targets.keys, parsed[1].targets.keys)
        assertEquals(original[0].joystick.radiusDp, parsed[0].joystick.radiusDp, 0.001f)
    }

    @Test fun invalidJsonReturnsNull() {
        assertNull(ProfileJson.fromJson("isto não é json"))
        assertNull(ProfileJson.fromJson(""))
    }

    @Test fun unsupportedSchemaReturnsNull() {
        assertNull(ProfileJson.fromJson("""{"schemaVersion": 99, "profiles": []}"""))
    }

    @Test fun unknownActionsAreSkippedAndEmptyProfileIsDropped() {
        val json = """{"schemaVersion":1,"profiles":[{"id":"x","name":"X","packageName":null,
          "joystick":{"x":0.1,"y":0.2,"radiusDp":50},
          "controls":[{"id":"q","action":"INEXISTENTE","label":"Q","x":0.1,"y":0.1,"sizeDp":50}]}]}"""
        assertTrue(ProfileJson.fromJson(json)!!.isEmpty())
    }

    @Test fun missingOrientationDefaultsToLandscapeAndValuesAreClamped() {
        val json = """{"schemaVersion":1,"profiles":[{"id":"x","name":"X","packageName":null,
          "joystick":{"x":5,"y":-2,"radiusDp":9999},
          "controls":[{"id":"w","action":"W","label":"W","x":3,"y":-1,"sizeDp":1}],
          "targets":[{"action":"SPACE","x":9,"y":9},{"action":"NADA","x":0,"y":0}]}]}"""
        val p = ProfileJson.fromJson(json)!!.single()
        assertEquals(Orientation.LANDSCAPE, p.orientation)
        assertEquals(1f, p.joystick.centerXFrac, 0f)
        assertEquals(0f, p.joystick.centerYFrac, 0f)
        assertEquals(300f, p.joystick.radiusDp, 0f)
        assertEquals(24f, p.controls[0].sizeDp, 0f)
        assertEquals(setOf(ControlAction.SPACE), p.targets.keys)
        assertEquals(1f, p.targets.getValue(ControlAction.SPACE).x, 0f)
    }
}
