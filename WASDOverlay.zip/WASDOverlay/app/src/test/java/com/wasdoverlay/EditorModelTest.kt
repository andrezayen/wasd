package com.wasdoverlay

import com.wasdoverlay.overlay.EditorModel
import com.wasdoverlay.model.Profile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EditorModelTest {
    @Test fun moveIsClampedToScreen() {
        val m = EditorModel(Profile.default())
        m.moveControl(0, 5f, -3f)
        assertEquals(1f, m.profile.controls[0].xFrac, 0f)
        assertEquals(0f, m.profile.controls[0].yFrac, 0f)
        m.moveControl(99, 0.5f, 0.5f) // índice inválido é ignorado
    }

    @Test fun radiusAndSizeAreBounded() {
        val m = EditorModel(Profile.default())
        repeat(100) { m.adjustRadius(10f); m.adjustSize(10f) }
        assertEquals(150f, m.profile.joystick.radiusDp, 0f)
        assertEquals(96f, m.profile.controls[0].sizeDp, 0f)
        repeat(100) { m.adjustRadius(-10f); m.adjustSize(-10f) }
        assertEquals(20f, m.profile.joystick.radiusDp, 0f)
        assertEquals(32f, m.profile.controls[0].sizeDp, 0f)
    }

    @Test fun detectsJoystickOverlappingButtons() {
        val m = EditorModel(Profile.default())
        assertFalse(m.joystickOverlapsControls(2400, 1080, 2.75f)) // padrão: afastados
        m.moveJoystick(0.30f, 0.40f) // em cima do botão W
        assertTrue(m.joystickOverlapsControls(2400, 1080, 2.75f))
    }
}
