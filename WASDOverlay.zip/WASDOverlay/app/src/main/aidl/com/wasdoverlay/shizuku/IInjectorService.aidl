package com.wasdoverlay.shizuku;

// Serviço que roda no processo shell (via Shizuku). 16777114 = método "destroy" exigido pelo Shizuku.
interface IInjectorService {
    void destroy() = 16777114;
    oneway void command(String line) = 1;
}
