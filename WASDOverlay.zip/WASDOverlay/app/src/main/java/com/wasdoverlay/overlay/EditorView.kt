package com.wasdoverlay.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import com.wasdoverlay.R
import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Profile
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Editor em tela cheia sobre o jogo: arraste os botões; arraste cada marcador laranja até o botão
 * correspondente DO JOGO (ou use "Capturar" e toque no ponto); leve o círculo ciano ao joystick do jogo.
 */
@SuppressLint("ViewConstructor")
class EditorView(
    context: Context,
    private val model: EditorModel,
    private val screenW: Int,
    private val screenH: Int,
    private val onSave: (Profile) -> Unit,
    private val onCancel: () -> Unit,
) : View(context) {

    private enum class Target { NONE, JOYSTICK, CONTROL, MARKER }

    private class Btn(val label: () -> String, val action: () -> Unit) { val rect = RectF() }
    private class Chip(val action: ControlAction, val rect: RectF)

    private val d = context.resources.displayMetrics.density
    private val gridPx = 16f * d
    private var gridOn = false
    private var paletteOpen = false
    private var captureMode = false
    private var chips: List<Chip> = emptyList()

    private var target = Target.NONE
    private var targetIndex = -1
    private var markerAction: ControlAction? = null
    private var startTouchX = 0f
    private var startTouchY = 0f
    private var startFracX = 0f
    private var startFracY = 0f

    private fun str(id: Int) = context.getString(id)

    private val rows: List<List<Btn>> = listOf(
        listOf(
            Btn({ str(R.string.editor_save) }) { onSave(model.profile) },
            Btn({ str(R.string.editor_cancel) }) { onCancel() },
            Btn({ str(R.string.editor_radius_minus) }) { model.adjustRadius(-5f) },
            Btn({ str(R.string.editor_radius_plus) }) { model.adjustRadius(5f) },
            Btn({ str(R.string.editor_size_minus) }) { model.adjustSize(-4f) },
            Btn({ str(R.string.editor_size_plus) }) { model.adjustSize(4f) },
        ),
        listOf(
            Btn({ str(R.string.editor_add) }) { openPalette() },
            Btn({ str(R.string.editor_duplicate) }) { model.duplicateSelected() },
            Btn({ str(R.string.editor_delete) }) { model.removeSelected() },
            Btn({ if (gridOn) str(R.string.editor_grid_on) else str(R.string.editor_grid_off) }) { gridOn = !gridOn },
            Btn({ str(R.string.editor_scale_minus) }) { model.adjustScale(-0.1f) },
            Btn({ str(R.string.editor_scale_plus) }) { model.adjustScale(0.1f) },
        ),
        listOf(
            Btn({ str(R.string.editor_opacity_minus) }) { model.adjustOpacity(-0.1f) },
            Btn({ str(R.string.editor_opacity_plus) }) { model.adjustOpacity(0.1f) },
            Btn({ str(R.string.editor_border) }) { model.toggleBorder() },
            Btn({ str(R.string.editor_corner_minus) }) { model.adjustCorner(-0.05f) },
            Btn({ str(R.string.editor_corner_plus) }) { model.adjustCorner(0.05f) },
            Btn({ str(R.string.editor_label) }) { model.toggleLabel() },
        ),
        listOf(
            Btn({ str(R.string.editor_capture) }) { captureMode = !captureMode },
        ),
    )
    private val buttons: List<Btn> = rows.flatten()
    private val rowH = 48f * d
    private val rowGap = 6f * d
    private val toolbarBottom = 12f * d + rows.size * (rowH + rowGap)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d }
    private val gridPaint = Paint().apply { color = 0x33FFFFFF; strokeWidth = 1f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val tmp = RectF()

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        rows.forEachIndexed { i, row -> layoutRow(row, 12f * d + i * (rowH + rowGap)) }
    }

    private fun layoutRow(row: List<Btn>, y: Float) {
        val gap = 8f * d
        val margin = 8f * d
        val bw = ((screenW - 2 * margin - gap * (6 - 1)) / 6).coerceAtMost(96f * d)
        val total = bw * row.size + gap * (row.size - 1)
        var x = (screenW - total) / 2f
        row.forEach {
            it.rect.set(x, y, x + bw, y + rowH)
            x += bw + gap
        }
    }

    private fun openPalette() {
        paletteOpen = true
        val cw = 62f * d
        val ch = 44f * d
        val gap = 6f * d
        val perRow = max(1, ((screenW - 16f * d) / (cw + gap)).toInt())
        chips = model.availableActions().mapIndexed { i, a ->
            val x = 8f * d + (i % perRow) * (cw + gap)
            val y = toolbarBottom + (i / perRow) * (ch + gap)
            Chip(a, RectF(x, y, x + cw, y + ch))
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(if (captureMode) 0x33000000 else 0x66000000)
        val profile = model.profile
        val overlap = model.joystickOverlapsControls(screenW, screenH, d)

        if (gridOn) {
            var x = 0f
            while (x < screenW) { canvas.drawLine(x, 0f, x, screenH.toFloat(), gridPaint); x += gridPx }
            var y = 0f
            while (y < screenH) { canvas.drawLine(0f, y, screenW.toFloat(), y, gridPaint); y += gridPx }
        }

        // Joystick do jogo
        val j = profile.joystick.toPx(screenW, screenH, d)
        stroke.color = if (overlap) Color.RED else 0xFF4DD0E1.toInt()
        canvas.drawCircle(j.center.x, j.center.y, j.radius, stroke)
        fill.color = stroke.color
        canvas.drawCircle(j.center.x, j.center.y, 6f * d, fill)
        KeyDrawer.drawCentered(canvas, str(R.string.editor_joystick_label), j.center.x, j.center.y - j.radius - 10f * d, 200f * d, 12f * d, text)

        // Botões (transparência real, com contorno para continuarem visíveis na edição)
        ControlsLayout.compute(profile, screenW, screenH, d)?.placed?.forEachIndexed { i, p ->
            tmp.set(p.rect.left, p.rect.top, p.rect.right, p.rect.bottom)
            val a = if (p.spec.opacity >= 0f) p.spec.opacity else 0.8f
            fill.color = Color.argb((255 * a).toInt().coerceIn(40, 255), 32, 32, 32)
            stroke.color = if (i == model.selected) Color.WHITE else 0xFFFFEB3B.toInt()
            KeyDrawer.draw(canvas, tmp, p.spec.label, fill, stroke, text, p.spec.corner, true, true)
        }

        // Marcadores: onde cada ação toca na tela do JOGO
        val selAction = profile.controls.getOrNull(model.selected)?.action
        profile.controls.map { it.action }.filter { !it.isMovement }.distinct().forEach { a ->
            val t = profile.targets[a] ?: return@forEach
            val cx = t.x * screenW
            val cy = t.y * screenH
            fill.color = if (a == selAction) 0xFFFF9800.toInt() else 0xCCFF9800.toInt()
            canvas.drawCircle(cx, cy, 20f * d, fill)
            text.color = Color.BLACK
            KeyDrawer.drawCentered(canvas, a.symbol, cx, cy, 34f * d, 12f * d, text)
            text.color = Color.WHITE
        }

        // Barra de ferramentas
        buttons.forEach { b ->
            fill.color = if (captureMode && b.label() == str(R.string.editor_capture)) 0xFFD32F2F.toInt() else 0xE6303030.toInt()
            canvas.drawRoundRect(b.rect, 8f * d, 8f * d, fill)
            KeyDrawer.drawCentered(canvas, b.label(), b.rect.centerX(), b.rect.centerY(), b.rect.width() * 0.9f, 13f * d, text)
        }

        // Paleta "+ Botão"
        if (paletteOpen) {
            chips.forEach { c ->
                fill.color = 0xF0404040.toInt()
                canvas.drawRoundRect(c.rect, 8f * d, 8f * d, fill)
                KeyDrawer.drawCentered(canvas, c.action.symbol, c.rect.centerX(), c.rect.centerY(), c.rect.width() * 0.85f, 14f * d, text)
            }
            if (chips.isEmpty()) {
                KeyDrawer.drawCentered(canvas, str(R.string.editor_palette_empty), screenW / 2f, screenH / 2f, screenW * 0.9f, 14f * d, text)
            }
        }

        // Dicas
        val hint = if (captureMode) R.string.editor_capture_hint else R.string.editor_hint
        KeyDrawer.drawCentered(canvas, str(hint), screenW / 2f, screenH - 28f * d, screenW * 0.96f, 14f * d, text)
        if (overlap) {
            text.color = Color.RED
            KeyDrawer.drawCentered(canvas, str(R.string.editor_overlap_warning), screenW / 2f, screenH - 52f * d, screenW * 0.96f, 14f * d, text)
            text.color = Color.WHITE
        }
    }

    private fun snapX(frac: Float): Float = if (gridOn) ((frac * screenW / gridPx).roundToInt() * gridPx) / screenW else frac
    private fun snapY(frac: Float): Float = if (gridOn) ((frac * screenH / gridPx).roundToInt() * gridPx) / screenH else frac

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                handleDown(e.x, e.y)
                startTouchX = e.x
                startTouchY = e.y
            }
            MotionEvent.ACTION_MOVE -> handleMove(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> target = Target.NONE
        }
        invalidate()
        return true
    }

    private fun handleDown(x: Float, y: Float) {
        target = Target.NONE
        buttons.firstOrNull { it.rect.contains(x, y) }?.let {
            val wasCapture = captureMode
            it.action()
            if (it.label() != str(R.string.editor_add)) paletteOpen = false
            if (wasCapture && captureMode && it.label() != str(R.string.editor_capture)) captureMode = false
            return
        }
        if (captureMode) { // o próximo toque fora da barra define o ponto no jogo
            model.captureAt((x / screenW).coerceIn(0f, 1f), (y / screenH).coerceIn(0f, 1f))
            captureMode = false
            return
        }
        if (paletteOpen) {
            chips.firstOrNull { it.rect.contains(x, y) }?.let { model.addControl(it.action) }
            paletteOpen = false
            return
        }
        val profile = model.profile
        val placed = ControlsLayout.compute(profile, screenW, screenH, d)?.placed.orEmpty()
        val idx = placed.indexOfLast { it.rect.contains(x, y) }
        if (idx >= 0) {
            model.select(idx)
            target = Target.CONTROL
            targetIndex = idx
            startFracX = profile.controls[idx].xFrac
            startFracY = profile.controls[idx].yFrac
            return
        }
        val markerHit = profile.controls.map { it.action }.filter { !it.isMovement }.distinct().firstOrNull { a ->
            val t = profile.targets[a] ?: return@firstOrNull false
            hypot(x - t.x * screenW, y - t.y * screenH) <= 24f * d
        }
        if (markerHit != null) {
            model.select(profile.controls.indexOfFirst { it.action == markerHit })
            target = Target.MARKER
            markerAction = markerHit
            startFracX = profile.targets.getValue(markerHit).x
            startFracY = profile.targets.getValue(markerHit).y
            return
        }
        val j = profile.joystick.toPx(screenW, screenH, d)
        if (hypot(x - j.center.x, y - j.center.y) <= max(j.radius, 40f * d)) {
            target = Target.JOYSTICK
            startFracX = profile.joystick.centerXFrac
            startFracY = profile.joystick.centerYFrac
        } else {
            model.select(-1)
        }
    }

    private fun handleMove(x: Float, y: Float) {
        val nx = snapX(startFracX + (x - startTouchX) / screenW)
        val ny = snapY(startFracY + (y - startTouchY) / screenH)
        when (target) {
            Target.CONTROL -> model.moveControl(targetIndex, nx, ny)
            Target.MARKER -> markerAction?.let { model.moveTarget(it, nx, ny) }
            Target.JOYSTICK -> model.moveJoystick(nx, ny)
            Target.NONE -> Unit
        }
    }
}
