package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.TouchGeometry
import java.util.EnumSet

/**
 * Backend baseado em AccessibilityService.dispatchGesture. NÃO envia teclas: simula toques
 * sustentados na tela do jogo (joystick virtual + pontos de ação). Ver [JoystickGestureEngine].
 */
class AccessibilityInputBackend(
    private val geometryProvider: () -> TouchGeometry?,
) : InputBackend {

    private val held: MutableSet<ControlAction> = EnumSet.noneOf(ControlAction::class.java)

    override val isAvailable: Boolean
        get() = InputAccessibilityService.instance?.engine != null

    override fun press(action: ControlAction) {
        held.add(action)
        push()
    }

    override fun release(action: ControlAction) {
        held.remove(action)
        push()
    }

    override fun releaseAll() {
        held.clear()
        push()
    }

    private fun push() {
        val engine = InputAccessibilityService.instance?.engine ?: return
        val g = geometryProvider()
        engine.setPlan(if (g == null || held.isEmpty()) emptyMap() else TouchTargets.compute(held.toSet(), g))
    }
}
