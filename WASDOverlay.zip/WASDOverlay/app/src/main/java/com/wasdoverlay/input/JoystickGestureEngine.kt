package com.wasdoverlay.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import com.wasdoverlay.control.AppRuntime
import com.wasdoverlay.model.LaneTarget
import com.wasdoverlay.model.Point
import com.wasdoverlay.util.DebugLog
import com.wasdoverlay.util.Screen

/**
 * Mantém vários toques simultâneos ("pistas": joystick + um por botão de ação) com traços
 * encadeados (StrokeDescription.willContinue + continueStroke, API 26+).
 *
 * O gesto é despachado em pedaços curtos; ao concluir um pedaço, o próximo continua cada traço
 * (move para o novo alvo, segura, ou levanta o dedo). Por isso a reação tem até ~[HOLD_MS] ms de
 * atraso. Quando o sistema cancela (o AOSP cancela gestos injetados a cada toque REAL que chega), o
 * motor re-despacha em ~8 ms e conta o cancelamento em AppRuntime.gestureCancels. Tudo roda na thread principal. Um watchdog destrava o ciclo se o sistema nunca chamar
 * o callback. Não verificado em hardware real.
 */
class JoystickGestureEngine(
    private val service: AccessibilityService,
    private val handler: Handler = Handler(Looper.getMainLooper()),
) {
    private class Lane(val stroke: StrokeDescription, val finger: Point)

    private var desired: Map<String, LaneTarget> = emptyMap()
    private var lanes: Map<String, Lane> = emptyMap()
    private var inFlight = false
    private var seq = 0

    fun setPlan(plan: Map<String, LaneTarget>) {
        desired = plan
        pump()
    }

    /** Levanta todos os dedos (no próximo pedaço, em no máximo ~[HOLD_MS] ms). */
    fun releaseAll() {
        desired = emptyMap()
        pump()
    }

    private fun pump() {
        if (inFlight) return // onCompleted/onCancelled chamará pump() de novo
        val size = Screen.size(service)
        val maxX = (size.width - 1).toFloat()
        val maxY = (size.height - 1).toFloat()
        fun clamp(p: Point) = Point(p.x.coerceIn(0f, maxX), p.y.coerceIn(0f, maxY))

        val strokes = ArrayList<StrokeDescription>()
        val next = HashMap<String, Lane?>() // null => dedo levantado
        val ids = LinkedHashSet<String>().apply { addAll(lanes.keys); addAll(desired.keys) }
        val maxStrokes = GestureDescription.getMaxStrokeCount()

        for (id in ids) {
            if (strokes.size >= maxStrokes) break
            val lane = lanes[id]
            val want = desired[id]
            if (want == null) {
                if (lane == null) continue
                val p = Path().apply { moveTo(lane.finger.x, lane.finger.y) }
                strokes += lane.stroke.continueStroke(p, 0, LIFT_MS, false)
                next[id] = null
            } else {
                val start = clamp(want.start)
                val target = clamp(want.target)
                if (lane == null) {
                    val p = Path().apply {
                        moveTo(start.x, start.y)
                        if (start != target) lineTo(target.x, target.y)
                    }
                    val s = StrokeDescription(p, 0, if (start != target) RAMP_MS else HOLD_MS, true)
                    strokes += s
                    next[id] = Lane(s, target)
                } else {
                    val moving = lane.finger != target
                    val p = Path().apply {
                        moveTo(lane.finger.x, lane.finger.y)
                        if (moving) lineTo(target.x, target.y)
                    }
                    val s = lane.stroke.continueStroke(p, 0, if (moving) RAMP_MS else HOLD_MS, true)
                    strokes += s
                    next[id] = Lane(s, target)
                }
            }
        }
        if (strokes.isEmpty()) return

        inFlight = true
        val mySeq = ++seq
        val ok = try {
            val builder = GestureDescription.Builder()
            strokes.forEach { builder.addStroke(it) }
            service.dispatchGesture(
                builder.build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (mySeq != seq) return
                        inFlight = false
                        val updated = HashMap(lanes)
                        for ((id, l) in next) if (l == null) updated.remove(id) else updated[id] = l
                        lanes = updated
                        pump()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (mySeq != seq) return
                        AppRuntime.gestureCancels.incrementAndGet()
                        DebugLog.d("gesto cancelado pelo sistema")
                        inFlight = false
                        lanes = emptyMap()
                        handler.postDelayed({ pump() }, RETRY_MS)
                    }
                },
                handler,
            )
        } catch (e: RuntimeException) {
            DebugLog.d("dispatchGesture falhou: ${e.javaClass.simpleName}")
            false
        }
        if (!ok) {
            inFlight = false
            lanes = emptyMap()
            return
        }
        handler.postDelayed({
            if (mySeq == seq && inFlight) { // callback nunca veio: destrava
                DebugLog.d("watchdog destravou o motor de gestos")
                seq++
                inFlight = false
                lanes = emptyMap()
                pump()
            }
        }, WATCHDOG_MS)
    }

    private companion object {
        const val RAMP_MS = 40L
        const val HOLD_MS = 100L
        const val LIFT_MS = 10L
        const val RETRY_MS = 8L
        const val WATCHDOG_MS = 1500L
    }
}
