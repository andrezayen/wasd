package com.wasdoverlay.ui

import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.view.ViewCompat
import com.google.android.material.materialswitch.MaterialSwitch
import com.wasdoverlay.BuildConfig
import com.wasdoverlay.R
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.util.DebugLog
import com.wasdoverlay.util.Haptics
import rikka.shizuku.Shizuku
import com.wasdoverlay.util.Ui

class SettingsActivity : AppCompatActivity() {

    private val settings by lazy { AppSettings(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val (sv, col) = Ui.scrollColumn(this)
        setContentView(sv)
        Ui.applyInsets(sv)

        col.addView(Ui.title(this, getString(R.string.set_title)).also { ViewCompat.setAccessibilityHeading(it, true) })

        col.addView(Ui.button(this, getString(R.string.set_language, currentLanguageName())) { chooseLanguage() })

        col.addView(Ui.body(this, getString(R.string.set_theme)))
        col.addView(radios(
            listOf("system" to R.string.set_theme_system, "light" to R.string.set_theme_light, "dark" to R.string.set_theme_dark),
            settings.themeMode,
        ) {
            settings.themeMode = it
            AppCompatDelegate.setDefaultNightMode(settings.nightMode)
        })

        col.addView(Ui.body(this, getString(R.string.set_input_mode)))
        col.addView(radios(
            listOf(
                "accessibility" to R.string.set_input_a11y,
                "privileged_keys" to R.string.set_input_keys,
                "privileged_touch" to R.string.set_input_touch,
            ),
            settings.inputMode,
        ) { settings.inputMode = it })
        col.addView(Ui.body(this, getString(R.string.set_source)))
        col.addView(radios(
            listOf(
                "auto" to R.string.set_source_auto,
                "shizuku" to R.string.set_source_shizuku,
                "root" to R.string.set_source_root,
            ),
            settings.privilegeSource,
        ) { settings.privilegeSource = it })
        col.addView(Ui.button(this, getString(R.string.set_shizuku_auth)) { authorizeShizuku() })
        col.addView(Ui.body(this, getString(R.string.set_input_note)))

        col.addView(toggle(R.string.set_vibration, settings.vibration) { settings.vibration = it })
        val strengthLabel = Ui.body(this, getString(R.string.set_vibration_strength, settings.vibrationStrength))
        col.addView(strengthLabel)
        col.addView(seek(10, 100, settings.vibrationStrength, strengthLabel) {
            settings.vibrationStrength = it
            strengthLabel.text = getString(R.string.set_vibration_strength, it)
            Haptics(this, it).tick() // sente a intensidade escolhida
        })
        col.addView(toggle(R.string.set_sound, settings.sound) { settings.sound = it })
        col.addView(toggle(R.string.set_bubble, settings.showBubble) { settings.showBubble = it })
        col.addView(toggle(R.string.set_autoload, settings.autoLoadProfile) { settings.autoLoadProfile = it })

        val opacityLabel = Ui.body(this, "")
        col.addView(opacityLabel)
        opacityLabel.text = getString(R.string.set_opacity, settings.opacityPercent)
        col.addView(seek(10, 100, settings.opacityPercent, opacityLabel) {
            settings.opacityPercent = it
            opacityLabel.text = getString(R.string.set_opacity, it)
        })

        val sizeLabel = Ui.body(this, "")
        col.addView(sizeLabel)
        sizeLabel.text = getString(R.string.set_size, settings.defaultSizeDp)
        col.addView(seek(32, 96, settings.defaultSizeDp, sizeLabel) {
            settings.defaultSizeDp = it
            sizeLabel.text = getString(R.string.set_size, it)
        })

        col.addView(Ui.body(this, getString(R.string.set_leave)))
        col.addView(radios(
            listOf("0" to R.string.set_leave_keep, "1" to R.string.set_leave_hide, "2" to R.string.set_leave_stop),
            settings.leaveBehavior.toString(),
        ) { settings.leaveBehavior = it.toInt() })

        if (BuildConfig.DEBUG) {
            col.addView(toggle(R.string.set_logs, settings.diagnosticLogs) {
                settings.diagnosticLogs = it
                DebugLog.enabled = it
            })
        }

        col.addView(Ui.body(this, getString(R.string.set_info, BuildConfig.VERSION_NAME, android.os.Build.VERSION.RELEASE), 24))
    }

    private fun toggle(label: Int, initial: Boolean, onChange: (Boolean) -> Unit): MaterialSwitch =
        MaterialSwitch(this).apply {
            setText(label)
            isChecked = initial
            setPadding(0, Ui.dp(this@SettingsActivity, 8), 0, Ui.dp(this@SettingsActivity, 8))
            minimumHeight = Ui.dp(this@SettingsActivity, 48)
            setOnCheckedChangeListener { _: CompoundButton, checked -> onChange(checked) }
        }

    private fun radios(options: List<Pair<String, Int>>, current: String, onSelect: (String) -> Unit): RadioGroup {
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val buttons = options.map { (value, label) ->
            RadioButton(this).apply {
                setText(label)
                tag = value
                id = android.view.View.generateViewId()
            }
        }
        buttons.forEach { group.addView(it) }
        buttons.firstOrNull { it.tag == current }?.isChecked = true
        group.setOnCheckedChangeListener { g, checkedId -> g.findViewById<RadioButton>(checkedId)?.let { onSelect(it.tag as String) } }
        return group
    }

    private fun seek(min: Int, max: Int, initial: Int, label: TextView, onChange: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        // TalkBack anuncia o texto do rótulo ("Transparência: 35%") ao focar a barra.
        if (id == View.NO_ID) id = View.generateViewId()
        if (label.id == View.NO_ID) label.id = View.generateViewId()
        label.labelFor = id
        this.max = max - min
        progress = initial - min
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress + min)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    // ------------------------------------------------------------------ idioma

    private val languages: List<Pair<String, String>> = listOf(
        "en" to "English", "pt" to "Português",
    )

    private fun currentLanguageName(): String {
        val tag = AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore(',').substringBefore('-')
        return languages.firstOrNull { it.first == tag }?.second ?: getString(R.string.set_lang_system)
    }

    private fun chooseLanguage() {
        val names = (listOf(getString(R.string.set_lang_system)) + languages.map { it.second }).toTypedArray()
        AlertDialog.Builder(this).setTitle(R.string.set_language_title).setItems(names) { _, i ->
            val locales = if (i == 0) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(languages[i - 1].first)
            AppCompatDelegate.setApplicationLocales(locales) // a Activity é recriada no novo idioma
        }.show()
    }

    // ------------------------------------------------------------------ Shizuku

    private fun authorizeShizuku() {
        try {
            when {
                !Shizuku.pingBinder() -> Toast.makeText(this, R.string.shizuku_not_running, Toast.LENGTH_LONG).show()
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                    Toast.makeText(this, R.string.shizuku_granted, Toast.LENGTH_SHORT).show()
                else -> Shizuku.requestPermission(REQUEST_SHIZUKU)
            }
        } catch (_: Throwable) {
            Toast.makeText(this, R.string.shizuku_not_running, Toast.LENGTH_LONG).show()
        }
    }

    private companion object { const val REQUEST_SHIZUKU = 1001 }
}
