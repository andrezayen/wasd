package com.wasdoverlay.input

import android.content.Context
import com.wasdoverlay.control.AppRuntime
import com.wasdoverlay.util.DebugLog
import java.io.IOException
import java.io.Writer
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * OPCIONAL (exige root; nunca é requisito do app). Abre `su` e executa nesta mesma APK o
 * processo auxiliar [com.wasdoverlay.root.RootInjector] via app_process. Os comandos são linhas de
 * texto enviadas por stdin, em uma única thread (ordem preservada, nada bloqueia a UI).
 */
class RootShell(private val context: Context) : InjectorLink {
    private val io = Executors.newSingleThreadExecutor()

    @Volatile private var process: Process? = null
    @Volatile private var writer: Writer? = null

    override val isAlive: Boolean get() = process?.isAlive == true

    override fun start() {
        try { io.execute { startBlocking() } } catch (_: RejectedExecutionException) { /* já encerrado */ }
    }

    private fun startBlocking() {
        if (isAlive) return
        try {
            val apk = context.applicationInfo.sourceDir
            val cmd = "CLASSPATH='$apk' exec app_process /system/bin $INJECTOR_CLASS"
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            process = p
            writer = p.outputStream.bufferedWriter()
            AppRuntime.privilegedActive = true
            AppRuntime.privilegedSource = "root"
            Thread {
                try {
                    val buf = ByteArray(512)
                    while (p.inputStream.read(buf) >= 0) { /* descarta a saída */ }
                } catch (_: IOException) {
                    // processo terminou
                }
                AppRuntime.privilegedActive = false
            }.apply { isDaemon = true; name = "root-drain" }.start()
        } catch (e: IOException) {
            DebugLog.d("su indisponível: ${e.javaClass.simpleName}")
            process = null
            writer = null
            AppRuntime.privilegedActive = false
        }
    }

    override fun send(line: String) {
        try {
            io.execute {
                try {
                    writer?.let { it.write(line); it.write("\n"); it.flush() }
                } catch (_: IOException) {
                    // processo morreu: isAlive passará a false
                }
            }
        } catch (_: RejectedExecutionException) {
            // encerrado
        }
    }

    /** Pede ao injetor para soltar tudo e sair; depois encerra o su. */
    override fun stop() {
        try {
            io.execute {
                try { writer?.let { it.write("Q\n"); it.flush() } } catch (_: IOException) { }
                process?.destroy()
                process = null
                writer = null
                AppRuntime.privilegedActive = false
            }
        } catch (_: RejectedExecutionException) { }
        io.shutdown()
    }

    private companion object {
        const val INJECTOR_CLASS = "com.wasdoverlay.root.RootInjector"
    }
}
