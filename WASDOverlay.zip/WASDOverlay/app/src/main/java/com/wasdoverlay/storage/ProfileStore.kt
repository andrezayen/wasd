package com.wasdoverlay.storage

import android.content.Context
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.model.Profile
import com.wasdoverlay.model.ProfileResolver
import java.io.File
import java.io.IOException

/** Perfis em arquivo JSON local (filesDir) + jogo ativo em SharedPreferences. */
class ProfileStore(context: Context) {
    private val appContext = context.applicationContext
    private val dir = appContext.filesDir
    private val file = File(dir, "profiles.json")
    private val prefs = appContext.getSharedPreferences("wasd_prefs", Context.MODE_PRIVATE)

    /** Pacote do jogo ativo; null = perfil padrão (sem jogo). */
    var activePackage: String?
        get() = prefs.getString(KEY_ACTIVE_PACKAGE, null)
        set(value) { prefs.edit().putString(KEY_ACTIVE_PACKAGE, value).apply() }

    fun all(): List<Profile> {
        if (!file.exists()) return emptyList()
        return try {
            ProfileJson.fromJson(file.readText()) ?: run {
                file.renameTo(File(dir, "profiles.corrupt.json")) // preserva o arquivo ruim
                emptyList()
            }
        } catch (_: IOException) {
            emptyList()
        }
    }

    /** Perfil do jogo ativo na orientação dada (ou um padrão novo, ainda não salvo). */
    fun resolveActive(orientation: String, defaultName: String = "Default profile"): Profile = ProfileResolver.resolve(
        all(), activePackage, orientation, AppSettings(appContext).defaultSizeDp.toFloat(), defaultName,
    )

    /** Primeira execução: cria o "Perfil padrão" (W A S D). */
    fun ensureDefault(name: String = "Default profile") {
        if (!file.exists()) save(Profile.default(Orientation.LANDSCAPE, name))
    }

    fun save(profile: Profile) = write(all().filterNot { it.id == profile.id } + profile)

    fun saveAll(profiles: List<Profile>) {
        val ids = profiles.map { it.id }.toSet()
        write(all().filterNot { it.id in ids } + profiles)
    }

    fun delete(id: String) = write(all().filterNot { it.id == id })

    fun deleteAll() {
        file.delete()
        activePackage = null
    }

    private fun write(list: List<Profile>) {
        val tmp = File(dir, "profiles.json.tmp")
        tmp.writeText(ProfileJson.toJson(list))
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    private companion object { const val KEY_ACTIVE_PACKAGE = "active_package" }
}
