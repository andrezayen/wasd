package com.wasdoverlay.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import com.wasdoverlay.model.Profile
import com.wasdoverlay.util.Screen

/** Janela do editor em tela cheia. Só abre por pedido explícito (nunca durante o jogo). */
class EditorController(private val context: Context) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private var view: EditorView? = null

    val isShown: Boolean get() = view != null

    fun show(profile: Profile, onSave: (Profile) -> Unit, onCancel: () -> Unit): Boolean {
        hide()
        val s = Screen.size(context)
        val v = EditorView(context, EditorModel(profile), s.width, s.height, onSave, onCancel)
        val lp = WindowManager.LayoutParams(
            s.width, s.height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return try {
            windowManager.addView(v, lp)
            view = v
            true
        } catch (_: RuntimeException) {
            false
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        try {
            windowManager.removeViewImmediate(v)
        } catch (_: IllegalArgumentException) {
            // já removida
        }
    }
}
