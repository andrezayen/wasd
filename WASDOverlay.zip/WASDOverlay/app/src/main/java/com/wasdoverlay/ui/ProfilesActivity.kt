package com.wasdoverlay.ui

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.wasdoverlay.R
import com.wasdoverlay.input.KeyCodes
import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.model.Preset
import com.wasdoverlay.model.Presets
import com.wasdoverlay.model.Profile
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.storage.ProfileJson
import com.wasdoverlay.storage.ProfileStore
import com.wasdoverlay.util.Ui
import java.io.IOException

/** Perfis: ativar, renomear, editar textos, aplicar preset, restaurar, exportar/importar, excluir. */
class ProfilesActivity : AppCompatActivity() {

    private val store by lazy { ProfileStore(this) }
    private lateinit var list: ListView
    private var profiles: List<Profile> = emptyList()
    private var pendingExport: Profile? = null

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val p = pendingExport
        pendingExport = null
        if (uri != null && p != null) writeText(uri, ProfileJson.toJson(listOf(p)))
    }

    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFrom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(Ui.title(this, getString(R.string.prof_title)).also {
            it.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 8))
        })
        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.VERTICAL
        buttons.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0)
        buttons.addView(Ui.button(this, getString(R.string.prof_import)) {
            importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
        })
        buttons.addView(Ui.button(this, getString(R.string.prof_reset_all)) {
            confirm(R.string.confirm_reset_all) {
                store.deleteAll()
                store.ensureDefault(getString(R.string.default_profile_name))
                refresh()
            }
        })
        root.addView(buttons)
        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        Ui.applyInsets(root)
        list.setOnItemClickListener { _, _, pos, _ -> showOptions(profiles[pos]) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        profiles = store.all().sortedBy { it.name.lowercase() }
        val items = profiles.map {
            val o = getString(if (it.orientation == Orientation.PORTRAIT) R.string.orientation_portrait else R.string.orientation_landscape)
            getString(R.string.prof_item, it.name, o)
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.ifEmpty { listOf(getString(R.string.prof_none)) })
    }

    private fun showOptions(p: Profile) {
        val names = listOf(
            R.string.prof_opt_activate, R.string.prof_opt_rename, R.string.prof_opt_labels, R.string.prof_opt_preset,
            R.string.prof_opt_keys, R.string.prof_opt_reset, R.string.prof_opt_export, R.string.prof_opt_delete,
        ).map { getString(it) }
        AlertDialog.Builder(this).setTitle(p.name).setItems(names.toTypedArray()) { _, which ->
            when (which) {
                0 -> {
                    store.activePackage = p.packageName
                    Toast.makeText(this, getString(R.string.prof_activated, p.name), Toast.LENGTH_SHORT).show()
                }
                1 -> askText(p.name, R.string.prof_name_hint, 40) { save(p.copy(name = it)) }
                2 -> editLabels(p)
                3 -> choosePreset(p)
                4 -> editCustomKeys(p)
                5 -> confirm(R.string.confirm_reset) { applyPreset(p, Preset.BASIC) }
                6 -> {
                    pendingExport = p
                    exportLauncher.launch(p.name.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".json")
                }
                7 -> confirm(R.string.confirm_delete) { store.delete(p.id); refresh() }
            }
        }.show()
    }

    private fun editLabels(p: Profile) {
        val items = p.controls.map { "${it.action.symbol}: ${it.label}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle(R.string.prof_opt_labels).setItems(items) { _, i ->
            askText(p.controls[i].label, R.string.prof_label_hint, 8) { text ->
                val updated = p.controls.toMutableList()
                updated[i] = updated[i].copy(label = text)
                save(p.copy(controls = updated))
            }
        }.show()
    }

    private fun presetTitle(p: Preset): String = getString(
        when (p) {
            Preset.BASIC -> R.string.preset_basic
            Preset.WASD_SPACE -> R.string.preset_space
            Preset.WASD_SPACE_SHIFT -> R.string.preset_space_shift
            Preset.FPS -> R.string.preset_fps
            Preset.MOBA -> R.string.preset_moba
        },
    )

    /** Tecla real de cada botão CUSTOM (usada nos modos de teclas reais). */
    private fun editCustomKeys(p: Profile) {
        val customs = ControlAction.entries.filter { it.name.startsWith("CUSTOM") }
        val items = customs.map { getString(R.string.prof_key_item, it.symbol, p.customKeys[it]?.let { k -> KeyCodes.nameOf(k) } ?: "—") }
        AlertDialog.Builder(this).setTitle(R.string.prof_opt_keys).setItems(items.toTypedArray()) { _, i ->
            val choices = KeyCodes.customChoices()
            AlertDialog.Builder(this).setTitle(R.string.prof_key_pick)
                .setItems(choices.map { it.first }.toTypedArray()) { _, j ->
                    save(p.copy(customKeys = p.customKeys + (customs[i] to choices[j].second)))
                }.show()
        }.show()
    }

    private fun choosePreset(p: Profile) {
        val presets = Preset.entries
        AlertDialog.Builder(this).setTitle(R.string.prof_opt_preset)
            .setItems(presets.map { presetTitle(it) }.toTypedArray()) { _, i ->
                confirm(R.string.confirm_reset) { applyPreset(p, presets[i]) }
            }.show()
    }

    private fun applyPreset(p: Profile, preset: Preset) {
        save(Presets.build(preset, p.packageName, p.name, p.orientation, AppSettings(this).defaultSizeDp.toFloat()))
    }

    private fun save(p: Profile) {
        store.save(p)
        refresh()
    }

    private fun askText(initial: String, hint: Int, maxLen: Int, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.setText(initial)
        input.setHint(hint)
        input.setSelection(input.text.length)
        AlertDialog.Builder(this).setView(input)
            .setPositiveButton(R.string.btn_ok) { _, _ ->
                val t = input.text.toString().trim().take(maxLen)
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton(R.string.btn_cancel, null).show()
    }

    private fun confirm(message: Int, onYes: () -> Unit) {
        AlertDialog.Builder(this).setTitle(R.string.confirm_title).setMessage(message)
            .setPositiveButton(R.string.btn_yes) { _, _ -> onYes() }
            .setNegativeButton(R.string.btn_cancel, null).show()
    }

    private fun writeText(uri: Uri, text: String) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
            Toast.makeText(this, R.string.ok_exported, Toast.LENGTH_SHORT).show()
        } catch (_: IOException) {
            Toast.makeText(this, R.string.err_export, Toast.LENGTH_LONG).show()
        }
    }

    private fun importFrom(uri: Uri) {
        val parsed = try {
            contentResolver.openInputStream(uri)?.use { String(it.readBytes()) }?.let { ProfileJson.fromJson(it) }
        } catch (_: IOException) {
            null
        }
        if (parsed == null || parsed.isEmpty()) {
            Toast.makeText(this, R.string.err_import, Toast.LENGTH_LONG).show()
            return
        }
        store.saveAll(parsed)
        refresh()
        Toast.makeText(this, getString(R.string.ok_imported, parsed.size), Toast.LENGTH_SHORT).show()
    }
}
