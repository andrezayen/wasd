package com.wasdoverlay.control

import java.util.concurrent.CopyOnWriteArrayList

enum class RunState { STOPPED, STARTING, RUNNING, PAUSED, STOPPING, ERROR }

/** Máquina de estados global do overlay. Rejeita transições impossíveis. */
class RunStateMachine {
    private val lock = Any()
    private val listeners = CopyOnWriteArrayList<(RunState) -> Unit>()

    @Volatile
    var state: RunState = RunState.STOPPED
        private set

    fun addListener(listener: (RunState) -> Unit) { listeners.add(listener) }
    fun removeListener(listener: (RunState) -> Unit) { listeners.remove(listener) }

    /** @return true se a transição foi aceita (ou já se estava no estado pedido). */
    fun transition(to: RunState): Boolean {
        synchronized(lock) {
            if (to == state) return true
            if (to !in ALLOWED.getValue(state)) return false
            state = to
        }
        listeners.forEach { it(to) }
        return true
    }

    /** Usado no onDestroy do serviço, onde o encerramento é incondicional. */
    fun forceStopped() {
        synchronized(lock) {
            if (state == RunState.STOPPED) return
            state = RunState.STOPPED
        }
        listeners.forEach { it(RunState.STOPPED) }
    }

    private companion object {
        val ALLOWED: Map<RunState, Set<RunState>> = mapOf(
            RunState.STOPPED to setOf(RunState.STARTING),
            RunState.STARTING to setOf(RunState.RUNNING, RunState.ERROR, RunState.STOPPING),
            RunState.RUNNING to setOf(RunState.PAUSED, RunState.STOPPING, RunState.ERROR),
            RunState.PAUSED to setOf(RunState.RUNNING, RunState.STOPPING, RunState.ERROR),
            RunState.STOPPING to setOf(RunState.STOPPED, RunState.ERROR),
            RunState.ERROR to setOf(RunState.STARTING, RunState.STOPPING, RunState.STOPPED),
        )
    }
}
