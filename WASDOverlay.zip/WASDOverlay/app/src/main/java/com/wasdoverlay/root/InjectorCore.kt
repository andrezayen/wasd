package com.wasdoverlay.root

import android.os.Build
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import java.lang.reflect.Method

/**
 * Injeta KeyEvent/MotionEvent com o método OCULTO `InputManager.injectInputEvent` (Android 14+:
 * `InputManagerGlobal`), via reflexão — a mesma técnica do scrcpy. Exige a permissão INJECT_EVENTS,
 * que só o uid shell (Shizuku) ou root têm; apps comuns NÃO têm.
 *
 * Protocolo (uma linha por comando): `D <keycode>` `U <keycode>` `X` (soltar teclas)
 * `T <id> <x> <y>` (pôr/mover dedo) `R <id>` (levantar dedo) `RA` (levantar todos).
 */
class InjectorCore {
    private val sink = Sink()
    private val keys = LinkedHashMap<Int, Long>() // keycode -> downTime
    private val touch = TouchState(sink)

    @Synchronized
    fun handle(line: String) {
        val p = line.trim().split(' ')
        when (p[0]) {
            "D" -> p.getOrNull(1)?.toIntOrNull()?.let { code ->
                if (!keys.containsKey(code)) {
                    val t = SystemClock.uptimeMillis()
                    keys[code] = t
                    sink.key(code, false, t)
                }
            }
            "U" -> p.getOrNull(1)?.toIntOrNull()?.let { code ->
                keys.remove(code)?.let { t -> sink.key(code, true, t) }
            }
            "X" -> releaseKeys()
            "T" -> {
                val x = p.getOrNull(2)?.toFloatOrNull()
                val y = p.getOrNull(3)?.toFloatOrNull()
                if (p.size >= 4 && x != null && y != null) touch.set(p[1], x, y)
            }
            "R" -> p.getOrNull(1)?.let { touch.release(it) }
            "RA" -> touch.releaseAll()
        }
    }

    /** Nada pode ficar preso: solta todas as teclas e todos os dedos. */
    @Synchronized
    fun releaseAll() {
        releaseKeys()
        touch.releaseAll()
    }

    private fun releaseKeys() {
        for ((code, downTime) in keys.toMap()) sink.key(code, true, downTime)
        keys.clear()
    }
}

private class Sink {
    private val manager: Any?
    private val method: Method?

    init {
        var m: Any? = null
        var meth: Method? = null
        try {
            val cls = if (Build.VERSION.SDK_INT >= 34) {
                Class.forName("android.hardware.input.InputManagerGlobal")
            } else {
                Class.forName("android.hardware.input.InputManager")
            }
            m = cls.getDeclaredMethod("getInstance").invoke(null)
            meth = m!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (t: Throwable) {
            System.err.println("InjectorCore: init falhou (${t.javaClass.simpleName})")
        }
        manager = m
        method = meth
    }

    fun inject(e: InputEvent) {
        try {
            method?.invoke(manager, e, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) {
            System.err.println("InjectorCore: inject falhou (${t.javaClass.simpleName})")
        }
    }

    fun key(code: Int, up: Boolean, downTime: Long) {
        val now = SystemClock.uptimeMillis()
        inject(
            KeyEvent(
                downTime, now, if (up) KeyEvent.ACTION_UP else KeyEvent.ACTION_DOWN, code, 0, 0,
                KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD,
            ),
        )
    }
}

/** Dedos simulados: cada pista tem um ID de ponteiro estável (0..9). */
private class TouchState(private val sink: Sink) {
    private val order = ArrayList<String>()
    private val pointerId = HashMap<String, Int>()
    private val xy = HashMap<String, FloatArray>()
    private var downTime = 0L

    fun set(lane: String, x: Float, y: Float) {
        if (xy.containsKey(lane)) {
            xy[lane] = floatArrayOf(x, y)
            send(MotionEvent.ACTION_MOVE)
            return
        }
        val free = (0..9).firstOrNull { it !in pointerId.values } ?: return
        order.add(lane)
        pointerId[lane] = free
        xy[lane] = floatArrayOf(x, y)
        val action = if (order.size == 1) {
            downTime = SystemClock.uptimeMillis()
            MotionEvent.ACTION_DOWN
        } else {
            MotionEvent.ACTION_POINTER_DOWN or (order.indexOf(lane) shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        }
        send(action)
    }

    fun release(lane: String) {
        val idx = order.indexOf(lane)
        if (idx < 0) return
        val action = if (order.size == 1) {
            MotionEvent.ACTION_UP
        } else {
            MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        }
        send(action) // o evento ainda inclui o ponteiro que está saindo
        order.removeAt(idx)
        pointerId.remove(lane)
        xy.remove(lane)
    }

    fun releaseAll() {
        while (order.isNotEmpty()) release(order.last())
    }

    private fun send(action: Int) {
        val n = order.size
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().also {
                it.id = pointerId.getValue(order[i])
                it.toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().also {
                val p = xy.getValue(order[i])
                it.x = p[0]
                it.y = p[1]
                it.pressure = 1f
                it.size = 1f
            }
        }
        val e = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0,
        )
        sink.inject(e)
        e.recycle()
    }
}
