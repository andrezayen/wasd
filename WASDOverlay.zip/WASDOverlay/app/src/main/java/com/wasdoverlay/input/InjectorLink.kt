package com.wasdoverlay.input

/** Canal para o processo privilegiado que injeta teclas/toques (su ou Shizuku). */
interface InjectorLink {
    val isAlive: Boolean
    fun start()
    fun send(line: String)
    fun stop()
}
