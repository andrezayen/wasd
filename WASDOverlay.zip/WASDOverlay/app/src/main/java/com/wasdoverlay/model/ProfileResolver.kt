package com.wasdoverlay.model

/** Escolhe o perfil de (jogo, orientação). Se não houver, devolve um novo padrão (não salvo). */
object ProfileResolver {
    fun resolve(
        profiles: List<Profile>,
        packageName: String?,
        orientation: String,
        sizeDp: Float = Presets.DEFAULT_SIZE_DP,
        defaultName: String = "Default profile",
    ): Profile {
        profiles.firstOrNull { it.packageName == packageName && it.orientation == orientation }?.let { return it }
        val name = profiles.firstOrNull { it.packageName == packageName }?.name ?: packageName ?: defaultName
        return Presets.build(Preset.BASIC, packageName, name, orientation, sizeDp)
    }
}
