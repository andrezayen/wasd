package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction

/** Teclas REAIS (KeyEvent injetado pelo processo privilegiado). [keyOf] devolve o keycode da ação (ou null). */
class PrivilegedKeyBackend(
    private val link: InjectorLink,
    private val keyOf: (ControlAction) -> Int?,
) : InputBackend {
    override val isAvailable: Boolean get() = link.isAlive

    override fun press(action: ControlAction) {
        val code = keyOf(action) ?: return
        link.send("D $code")
    }

    override fun release(action: ControlAction) {
        val code = keyOf(action) ?: return
        link.send("U $code")
    }

    override fun releaseAll() = link.send("X")
}
