package com.wasdoverlay.model

/** Tipos geométricos puros (sem android.graphics) para permitir testes unitários na JVM. */
data class Point(val x: Float, val y: Float)

data class PxRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom
}

/** Joystick virtual do jogo, em pixels de tela. */
data class JoystickPx(val center: Point, val radius: Float)

/** Um "dedo" simulado: começa em [start] e deve ficar em [target]. */
data class LaneTarget(val start: Point, val target: Point)

/** Tudo que o backend precisa, já em pixels: joystick e pontos de toque das demais ações. */
data class TouchGeometry(val joystick: JoystickPx, val actionPoints: Map<ControlAction, Point>)
