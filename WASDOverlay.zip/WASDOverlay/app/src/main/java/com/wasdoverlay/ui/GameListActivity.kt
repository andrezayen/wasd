package com.wasdoverlay.ui

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.wasdoverlay.R
import com.wasdoverlay.model.Preset
import com.wasdoverlay.model.Presets
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.storage.ProfileStore
import com.wasdoverlay.util.Screen
import com.wasdoverlay.util.Ui

/** Lista os apps instalados com ícone de launcher; escolher um ativa (e cria, se preciso) o perfil dele. */
class GameListActivity : AppCompatActivity() {

    private data class Entry(val label: String, val pkg: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val list = ListView(this)
        root.addView(Ui.title(this, getString(R.string.pick_game_title)).also {
            it.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 8))
        })
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        Ui.applyInsets(root)
        Thread {
            val entries = loadEntries()
            runOnUiThread {
                list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entries.map { it.label })
                list.setOnItemClickListener { _, _, pos, _ -> choose(entries[pos]) }
            }
        }.start()
    }

    private fun loadEntries(): List<Entry> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val infos = pm.queryIntentActivities(intent, 0)
        return infos
            .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun choose(e: Entry) {
        val store = ProfileStore(this)
        if (store.all().none { it.packageName == e.pkg }) {
            store.save(
                Presets.build(
                    Preset.BASIC, e.pkg, e.label, Screen.orientation(this),
                    AppSettings(this).defaultSizeDp.toFloat(),
                ),
            )
        }
        store.activePackage = e.pkg
        finish()
    }
}
