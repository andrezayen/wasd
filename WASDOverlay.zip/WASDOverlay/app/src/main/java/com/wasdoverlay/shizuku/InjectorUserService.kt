package com.wasdoverlay.shizuku

import com.wasdoverlay.root.InjectorCore
import kotlin.system.exitProcess

/**
 * UserService do Shizuku: roda num processo com identidade de SHELL (sem root) e injeta as
 * teclas/toques. O Shizuku instancia esta classe por nome; `destroy` é exigido pelo Shizuku.
 */
class InjectorUserService : IInjectorService.Stub() {
    private val core = InjectorCore()

    override fun destroy() {
        core.releaseAll()
        exitProcess(0)
    }

    override fun command(line: String?) {
        if (line != null) core.handle(line)
    }
}
