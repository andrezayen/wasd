package com.wasdoverlay.control

import com.wasdoverlay.input.InputBackend
import com.wasdoverlay.model.ControlAction
import java.util.EnumMap

/**
 * Estado dos botões. Associa cada ponteiro (dedo) a no máximo um botão e só pede ao
 * [InputBackend] "press" na 1ª vez que uma ação fica ativa e "release" quando o último dedo
 * dessa ação sai. Qualquer exceção do backend dispara [releaseAllControls].
 *
 * Não é thread-safe: use sempre na thread principal.
 */
class ControlStateManager(
    private val backend: InputBackend,
    private val onChange: () -> Unit = {},
    private val onError: (Throwable) -> Unit = {},
) {
    private val pointerToAction = HashMap<Int, ControlAction>()
    private val holdCount = EnumMap<ControlAction, Int>(ControlAction::class.java)

    fun activeActions(): Set<ControlAction> = holdCount.keys.toSet()
    fun isPressed(action: ControlAction): Boolean = (holdCount[action] ?: 0) > 0

    /** Ação à qual este dedo está ligado agora (null se nenhuma). */
    fun actionOf(pointerId: Int): ControlAction? = pointerToAction[pointerId]

    fun pointerDown(pointerId: Int, action: ControlAction) = update { bind(pointerId, action) }

    /** O dedo deslizou para outro botão: libera o antigo (se mais ninguém o segura) e ativa o novo. */
    fun pointerMoved(pointerId: Int, action: ControlAction) = update {
        if (pointerToAction[pointerId] != action) bind(pointerId, action)
    }

    fun pointerUp(pointerId: Int) = update { unbind(pointerId) }

    /** Rotina de segurança: libera tudo, sempre, mesmo que o backend falhe. */
    fun releaseAllControls() {
        forceRelease()
        onChange()
    }

    private fun bind(pointerId: Int, action: ControlAction) {
        unbind(pointerId)
        pointerToAction[pointerId] = action
        val n = (holdCount[action] ?: 0) + 1
        holdCount[action] = n
        if (n == 1) backend.press(action)
    }

    private fun unbind(pointerId: Int) {
        val action = pointerToAction.remove(pointerId) ?: return
        val n = (holdCount[action] ?: 0) - 1
        if (n <= 0) {
            holdCount.remove(action)
            backend.release(action)
        } else {
            holdCount[action] = n
        }
    }

    private inline fun update(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            reportError(e)
            forceRelease()
        }
        onChange()
    }

    private fun forceRelease() {
        pointerToAction.clear()
        holdCount.clear()
        try {
            backend.releaseAll()
        } catch (e: Exception) {
            reportError(e)
        }
    }

    private fun reportError(e: Exception) {
        try { onError(e) } catch (_: Exception) { /* nunca deixar o log derrubar a liberação */ }
    }
}
