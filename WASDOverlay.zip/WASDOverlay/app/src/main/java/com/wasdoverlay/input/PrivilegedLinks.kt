package com.wasdoverlay.input

import android.content.Context

/** Escolhe a origem do acesso privilegiado: "shizuku" (sem root), "root" (su) ou "auto" (Shizuku e, se não der, su). */
object PrivilegedLinks {
    fun create(context: Context, source: String): InjectorLink = when (source) {
        "shizuku" -> ShizukuLink(context)
        "root" -> RootShell(context)
        else -> AutoLink(ShizukuLink(context), RootShell(context))
    }
}

class AutoLink(private val shizuku: ShizukuLink, private val root: RootShell) : InjectorLink {
    override val isAlive: Boolean get() = shizuku.isAlive || root.isAlive

    override fun start() {
        if (shizuku.isReady()) shizuku.start() else root.start()
    }

    override fun send(line: String) {
        if (shizuku.isAlive) shizuku.send(line) else root.send(line)
    }

    override fun stop() {
        shizuku.stop()
        root.stop()
    }
}
