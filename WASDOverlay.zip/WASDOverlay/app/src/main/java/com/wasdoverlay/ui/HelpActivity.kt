package com.wasdoverlay.ui

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.wasdoverlay.R
import com.wasdoverlay.util.Ui

class HelpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val (sv, col) = Ui.scrollColumn(this)
        setContentView(sv)
        Ui.applyInsets(sv)
        col.addView(Ui.title(this, getString(R.string.help_title)))
        col.addView(Ui.body(this, getString(R.string.help_text), 16))
    }
}
