package com.wasdoverlay.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SoundEffectConstants
import android.view.View
import com.wasdoverlay.control.ControlStateManager
import com.wasdoverlay.util.Haptics
import kotlin.math.max

/** Aparência/feedback do overlay de jogo (vem das configurações). */
data class OverlayStyle(
    val opacity: Float = 0.35f,
    val haptic: Boolean = false,
    val hapticStrength: Int = 50,
    val sound: Boolean = false,
)

/**
 * UM botão = UMA janela do tamanho exato do botão: o espaço entre os botões fica livre e o toque
 * chega ao jogo. Mesmo assim o dedo pode deslizar para outro botão: o MotionEvent continua com a
 * janela onde o dedo desceu, e as coordenadas de TELA (rawX/rawY) dizem em qual botão ele está.
 * IDs de ponteiro são por janela, então a chave global é (índice do botão * 16 + id do ponteiro).
 */
@SuppressLint("ViewConstructor")
class ButtonView(
    context: Context,
    private val index: Int,
    private val placed: PlacedControl,
    private val layout: ControlsLayout,
    private val manager: ControlStateManager,
    private val style: OverlayStyle,
) : View(context) {

    private val density = context.resources.displayMetrics.density
    private val spec = placed.spec
    private val mine = HashSet<Int>()
    private val haptics = if (style.haptic) Haptics(context, style.hapticStrength) else null
    private val r = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = 0x99FFFFFF.toInt()
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val opacity = if (spec.opacity >= 0f) spec.opacity else style.opacity
    private val normalColor = Color.argb((255 * opacity).toInt().coerceIn(25, 255), 32, 32, 32)
    private val pressedColor = Color.argb(max(204, (255 * opacity).toInt()), 61, 220, 132)

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun key(pointerId: Int) = index * 16 + pointerId

    override fun onDraw(canvas: Canvas) {
        r.set(border.strokeWidth / 2f, border.strokeWidth / 2f, width - border.strokeWidth / 2f, height - border.strokeWidth / 2f)
        fill.color = if (manager.isPressed(spec.action)) pressedColor else normalColor
        KeyDrawer.draw(canvas, r, spec.label, fill, border, text, spec.corner, spec.border, spec.showLabel)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val k = key(event.getPointerId(event.actionIndex))
                mine.add(k)
                manager.pointerDown(k, spec.action)
                feedback()
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val k = key(event.getPointerId(i))
                    if (k !in mine) continue
                    // Só troca ao entrar em OUTRO botão; nas frestas o dedo continua no atual.
                    val hit = layout.hitTestScreen(event.getRawX(i), event.getRawY(i)) ?: continue
                    if (manager.actionOf(k) != hit.spec.action) {
                        manager.pointerMoved(k, hit.spec.action)
                        feedback()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val k = key(event.getPointerId(event.actionIndex))
                if (mine.remove(k)) manager.pointerUp(k)
            }
            MotionEvent.ACTION_CANCEL -> releaseMine()
        }
        return true
    }

    private fun feedback() {
        haptics?.tick()
        if (style.sound) playSoundEffect(SoundEffectConstants.CLICK)
    }

    /** Solta só os dedos desta janela (os de outras janelas continuam). */
    private fun releaseMine() {
        val copy = mine.toList()
        mine.clear()
        copy.forEach { manager.pointerUp(it) }
    }

    override fun onDetachedFromWindow() {
        releaseMine()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != VISIBLE) releaseMine()
        super.onWindowVisibilityChanged(visibility)
    }
}
