package com.wasdoverlay

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.util.DebugLog

class WasdApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val s = AppSettings(this)
        AppCompatDelegate.setDefaultNightMode(s.nightMode)
        DebugLog.enabled = BuildConfig.DEBUG && s.diagnosticLogs
    }
}
