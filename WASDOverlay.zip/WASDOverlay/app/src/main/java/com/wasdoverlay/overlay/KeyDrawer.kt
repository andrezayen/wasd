package com.wasdoverlay.overlay

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

object KeyDrawer {
    /** Desenha uma tecla; o texto encolhe para caber (ex.: "SPACE"). */
    fun draw(
        canvas: Canvas,
        r: RectF,
        label: String,
        fill: Paint,
        border: Paint,
        text: Paint,
        corner: Float = 0.2f,
        drawBorder: Boolean = true,
        showLabel: Boolean = true,
    ) {
        val radius = r.width() * corner
        canvas.drawRoundRect(r, radius, radius, fill)
        if (drawBorder) canvas.drawRoundRect(r, radius, radius, border)
        if (showLabel) drawCentered(canvas, label, r.centerX(), r.centerY(), r.width() * 0.84f, r.height() * 0.42f, text)
    }

    fun drawCentered(canvas: Canvas, label: String, cx: Float, cy: Float, maxWidth: Float, baseSize: Float, text: Paint) {
        text.textSize = baseSize
        val w = text.measureText(label)
        if (w > maxWidth && w > 0f) text.textSize = baseSize * maxWidth / w
        canvas.drawText(label, cx, cy - (text.ascent() + text.descent()) / 2f, text)
    }
}
