package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.JoystickPx
import com.wasdoverlay.model.Point
import kotlin.math.sqrt

/** Lógica pura: dado o conjunto de ações ativas, onde o "dedo" deve estar no joystick do jogo. */
object JoystickPlanner {
    /**
     * @return null se nada está ativo (dedo deve ser levantado); o centro se as direções se
     * anulam (ex.: W+S); senão um ponto a [JoystickPx.radius] do centro. Diagonais são
     * normalizadas para não ultrapassarem o raio.
     */
    fun target(active: Set<ControlAction>, joystick: JoystickPx): Point? {
        if (active.isEmpty()) return null
        var vx = 0f
        var vy = 0f
        for (a in active) {
            vx += a.dx
            vy += a.dy
        }
        val len = sqrt(vx * vx + vy * vy)
        if (len == 0f) return joystick.center
        val k = joystick.radius / len
        return Point(joystick.center.x + vx * k, joystick.center.y + vy * k)
    }
}
