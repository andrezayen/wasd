package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.LaneTarget
import com.wasdoverlay.model.TouchGeometry

/** Lógica pura: ações ativas -> "dedos" simulados (um por pista). */
object TouchTargets {
    const val JOYSTICK_LANE = "joystick"

    fun compute(active: Set<ControlAction>, g: TouchGeometry): Map<String, LaneTarget> {
        val out = LinkedHashMap<String, LaneTarget>()
        val moves = active.filter { it.isMovement }.toSet()
        JoystickPlanner.target(moves, g.joystick)?.let { out[JOYSTICK_LANE] = LaneTarget(g.joystick.center, it) }
        for (a in active) {
            if (a.isMovement) continue
            g.actionPoints[a]?.let { out[a.name] = LaneTarget(it, it) }
        }
        return out
    }
}
