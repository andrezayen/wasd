package com.wasdoverlay.model

object Orientation {
    const val LANDSCAPE = "landscape"
    const val PORTRAIT = "portrait"
}

/** Ponto como fração da tela (0..1): adapta a resoluções diferentes. */
data class FracPoint(val x: Float, val y: Float)

/** Botão do overlay. Posição (canto superior esquerdo) como fração da tela. */
data class ControlSpec(
    val id: String,
    val action: ControlAction,
    val label: String,
    val xFrac: Float,
    val yFrac: Float,
    val sizeDp: Float,
    /** Transparência deste botão (0.1..1); negativo = usar a das Configurações. */
    val opacity: Float = -1f,
    val border: Boolean = true,
    /** Raio dos cantos como fração do lado (0 = quadrado, 0.5 = círculo). */
    val corner: Float = 0.2f,
    val showLabel: Boolean = true,
)

/** Onde fica o joystick do jogo (fração da tela) e o alcance do arrasto em dp. */
data class JoystickCalibration(val centerXFrac: Float, val centerYFrac: Float, val radiusDp: Float) {
    fun toPx(screenW: Int, screenH: Int, density: Float) = JoystickPx(
        center = Point(centerXFrac * screenW, centerYFrac * screenH),
        radius = radiusDp * density,
    )
}

/**
 * Perfil = um layout para UM jogo em UMA orientação (id = "pacote|orientação").
 * [targets]: para cada ação que não é movimento, o ponto da tela do jogo a ser tocado.
 */
data class Profile(
    val id: String,
    val name: String,
    val packageName: String?,
    val orientation: String,
    val joystick: JoystickCalibration,
    val controls: List<ControlSpec>,
    val targets: Map<ControlAction, FracPoint> = emptyMap(),
    val overlayScale: Float = 1f,
    /** Tecla (keycode do Android) de cada botão CUSTOM, usada nos modos de teclas reais. */
    val customKeys: Map<ControlAction, Int> = emptyMap(),
) {
    fun geometry(screenW: Int, screenH: Int, density: Float) = TouchGeometry(
        joystick = joystick.toPx(screenW, screenH, density),
        actionPoints = targets.mapValues { Point(it.value.x * screenW, it.value.y * screenH) },
    )

    companion object {
        fun idFor(packageName: String?, orientation: String) = "${packageName ?: "default"}|$orientation"

        fun forApp(packageName: String?, name: String, orientation: String): Profile =
            Presets.build(Preset.BASIC, packageName, name, orientation)

        fun default(orientation: String = Orientation.LANDSCAPE, name: String = "Default profile"): Profile =
            forApp(null, name, orientation)
    }
}
