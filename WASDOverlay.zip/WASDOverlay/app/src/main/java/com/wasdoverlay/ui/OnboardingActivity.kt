package com.wasdoverlay.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.wasdoverlay.R
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.util.Ui

/** Primeira execução: 5 telas curtas (boas-vindas, sobreposição, entrada, primeiro layout, pronto). */
class OnboardingActivity : AppCompatActivity() {

    private class Step(val title: Int, val body: Int, val actionLabel: Int?, val action: (() -> Unit)?)

    private var index = 0
    private lateinit var titleView: TextView
    private lateinit var bodyView: TextView
    private lateinit var actionButton: MaterialButton
    private lateinit var nextButton: MaterialButton
    private lateinit var steps: List<Step>

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        steps = listOf(
            Step(R.string.onb_t1, R.string.onb_b1, null, null),
            Step(R.string.onb_t2, R.string.onb_b2, R.string.btn_overlay_permission) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            },
            Step(R.string.onb_t3, R.string.onb_b3, R.string.btn_accessibility) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            Step(R.string.onb_t4, R.string.onb_b4, R.string.btn_pick_game) {
                startActivity(Intent(this, GameListActivity::class.java))
            },
            Step(R.string.onb_t5, R.string.onb_b5, null, null),
        )
        val (sv, col) = Ui.scrollColumn(this)
        setContentView(sv)
        Ui.applyInsets(sv)
        titleView = Ui.title(this, "")
        bodyView = Ui.body(this, "", 16)
        actionButton = Ui.button(this, "") { steps[index].action?.invoke() }
        nextButton = Ui.button(this, "") { next() }
        val skip = Ui.button(this, getString(R.string.onb_skip)) { finishOnboarding() }
        col.addView(titleView)
        col.addView(bodyView)
        col.addView(actionButton, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = Ui.dp(this, 24) })
        col.addView(nextButton)
        col.addView(skip)
        render()
    }

    private fun render() {
        val s = steps[index]
        titleView.setText(s.title)
        bodyView.setText(s.body)
        if (s.actionLabel != null) {
            actionButton.setText(s.actionLabel)
            actionButton.visibility = android.view.View.VISIBLE
        } else {
            actionButton.visibility = android.view.View.GONE
        }
        nextButton.setText(if (index == steps.lastIndex) R.string.onb_done else R.string.onb_next)
    }

    private fun next() {
        if (index == steps.lastIndex) {
            finishOnboarding()
        } else {
            index++
            render()
        }
    }

    private fun finishOnboarding() {
        AppSettings(this).onboardingDone = true
        finish()
    }
}
