package com.wasdoverlay.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import com.wasdoverlay.R
import com.wasdoverlay.control.AppRuntime
import com.wasdoverlay.control.ControlStateManager
import com.wasdoverlay.control.RunState
import com.wasdoverlay.input.AccessibilityInputBackend
import com.wasdoverlay.input.CompositeInputBackend
import com.wasdoverlay.input.InjectorLink
import com.wasdoverlay.input.InputAccessibilityService
import com.wasdoverlay.input.InputBackend
import com.wasdoverlay.input.KeyCodes
import com.wasdoverlay.input.PrivilegedKeyBackend
import com.wasdoverlay.input.PrivilegedLinks
import com.wasdoverlay.input.PrivilegedTouchBackend
import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Profile
import com.wasdoverlay.model.TouchGeometry
import com.wasdoverlay.overlay.BubbleController
import com.wasdoverlay.overlay.EditorController
import com.wasdoverlay.overlay.OverlayController
import com.wasdoverlay.overlay.OverlayStyle
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.storage.ProfileStore
import com.wasdoverlay.util.DebugLog
import com.wasdoverlay.util.Screen

/**
 * Serviço em primeiro plano que hospeda o overlay de jogo, o editor e o botão flutuante.
 * É necessário para manter o processo vivo enquanto o jogo está em primeiro plano. O overlay
 * funciona mesmo sem o serviço de acessibilidade (só visual).
 */
class OverlayService : Service() {

    private lateinit var settings: AppSettings
    private lateinit var store: ProfileStore
    private lateinit var stateManager: ControlStateManager
    private lateinit var overlay: OverlayController
    private lateinit var editor: EditorController
    private lateinit var bubble: BubbleController

    private var profile: Profile = Profile.default()
    private var privilegedLink: InjectorLink? = null
    private var knownPackages: Set<String> = emptySet()
    private var hiddenByLeaving = false
    private var startedAt = 0L
    private var receiverRegistered = false
    private val main = Handler(Looper.getMainLooper())

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            stateManager.releaseAllControls() // tela bloqueada => nada pode ficar preso
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        store = ProfileStore(this)
        val backend = buildBackend()
        stateManager = ControlStateManager(
            backend,
            onChange = { overlay.refresh() },
            onError = { DebugLog.d("erro no backend: ${it.javaClass.simpleName}") },
        )
        overlay = OverlayController(this, stateManager)
        editor = EditorController(this)
        bubble = BubbleController(
            this,
            onToggle = { main.post { toggleVisibility() } },
            onEdit = { main.post { openEditor() } },
            onSwitch = { main.post { cycleProfile() } },
            onStop = { main.post { shutdown() } },
        )
        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        receiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> shutdown()
            ACTION_TOGGLE -> toggleVisibility()
            ACTION_EDIT -> start(edit = true)
            else -> start(edit = false)
        }
        return START_NOT_STICKY
    }

    /** Acessibilidade por padrão; modos privilegiados (Shizuku/root) são opcionais e caem para ela se falharem. */
    private fun buildBackend(): InputBackend {
        val a11y = AccessibilityInputBackend { currentGeometry() }
        val mode = settings.inputMode
        if (mode != "privileged_keys" && mode != "privileged_touch") return a11y
        val link = PrivilegedLinks.create(this, settings.privilegeSource).also { privilegedLink = it; it.start() }
        return if (mode == "privileged_keys") {
            val keyOf: (ControlAction) -> Int? = { KeyCodes.of(it) ?: profile.customKeys[it] }
            CompositeInputBackend(PrivilegedKeyBackend(link, keyOf), { keyOf(it) != null }, a11y)
        } else {
            CompositeInputBackend(PrivilegedTouchBackend(link) { currentGeometry() }, { true }, a11y)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    private fun start(edit: Boolean) {
        val sm = AppRuntime.state
        // Quem usou startForegroundService() exige startForeground() em poucos segundos: SEMPRE chamar.
        val inForeground = enterForeground()
        if (!inForeground || !Settings.canDrawOverlays(this)) {
            fail()
            return
        }
        if (sm.state == RunState.RUNNING || sm.state == RunState.PAUSED) {
            if (edit) openEditor() else if (sm.state == RunState.PAUSED) toggleVisibility()
            return
        }
        if (!sm.transition(RunState.STARTING)) return
        startedAt = SystemClock.elapsedRealtime()
        hiddenByLeaving = false
        loadProfile()
        InputAccessibilityService.foregroundListener = { pkg -> onForegroundChanged(pkg) }
        if (edit) {
            sm.transition(RunState.RUNNING)
            openEditor()
        } else {
            showPlayOverlay()
        }
    }

    private fun enterForeground(): Boolean = try {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (e: RuntimeException) {
        DebugLog.d("startForeground falhou: ${e.javaClass.simpleName}")
        false
    }

    private fun fail() {
        val sm = AppRuntime.state
        if (sm.state == RunState.STOPPED) sm.transition(RunState.STARTING)
        sm.transition(RunState.ERROR)
        stopSelf()
    }

    private fun shutdown() {
        AppRuntime.state.transition(RunState.STOPPING)
        stateManager.releaseAllControls()
        InputAccessibilityService.foregroundListener = null
        editor.hide()
        bubble.hide()
        overlay.hide()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stateManager.releaseAllControls()
        InputAccessibilityService.foregroundListener = null
        editor.hide()
        bubble.hide()
        overlay.hide()
        if (receiverRegistered) {
            unregisterReceiver(screenOffReceiver)
            receiverRegistered = false
        }
        privilegedLink?.stop()
        privilegedLink = null
        val sm = AppRuntime.state
        if (sm.state != RunState.ERROR) sm.forceStopped()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- overlay / editor

    private fun loadProfile() {
        profile = store.resolveActive(Screen.orientation(this), getString(R.string.default_profile_name))
        knownPackages = store.all().mapNotNull { it.packageName }.toSet()
    }

    private fun style() = OverlayStyle(settings.opacityPercent / 100f, settings.vibration, settings.vibrationStrength, settings.sound)

    private fun showPlayOverlay() {
        hiddenByLeaving = false
        if (overlay.show(profile, style())) {
            AppRuntime.state.transition(RunState.RUNNING)
            syncBubble()
        } else {
            AppRuntime.state.transition(RunState.ERROR)
            shutdown()
        }
    }

    private fun hidePlayOverlay() {
        overlay.hide() // também chama releaseAllControls()
        AppRuntime.state.transition(RunState.PAUSED)
        syncBubble()
    }

    private fun syncBubble() {
        val sm = AppRuntime.state.state
        val active = sm == RunState.RUNNING || sm == RunState.PAUSED
        if (settings.showBubble && active && !editor.isShown) bubble.show(controlsHidden = sm == RunState.PAUSED) else bubble.hide()
    }

    private fun openEditor() {
        loadProfile()
        stateManager.releaseAllControls()
        overlay.hide()
        bubble.hide()
        val shown = editor.show(
            profile,
            onSave = { p -> main.post { saveAndPlay(p) } },
            onCancel = { main.post { closeEditor() } },
        )
        if (!shown) showPlayOverlay()
    }

    private fun saveAndPlay(p: Profile) {
        store.save(p)
        profile = p
        knownPackages = store.all().mapNotNull { it.packageName }.toSet()
        editor.hide()
        showPlayOverlay()
    }

    private fun closeEditor() {
        editor.hide()
        showPlayOverlay()
    }

    private fun toggleVisibility() {
        if (editor.isShown) return // nunca alternar durante a edição
        when (AppRuntime.state.state) {
            RunState.RUNNING -> hidePlayOverlay()
            RunState.PAUSED -> showPlayOverlay()
            else -> Unit
        }
    }

    /** Botão flutuante "Perfil": passa para o próximo jogo salvo (e depois para o perfil padrão). */
    private fun cycleProfile() {
        val sm = AppRuntime.state.state
        if (editor.isShown || (sm != RunState.RUNNING && sm != RunState.PAUSED)) return
        val packages = listOf<String?>(null) + store.all().mapNotNull { it.packageName }.distinct().sorted()
        val next = packages[(packages.indexOf(store.activePackage) + 1) % packages.size]
        stateManager.releaseAllControls()
        store.activePackage = next
        loadProfile()
        if (sm == RunState.RUNNING) showPlayOverlay()
        Toast.makeText(this, profile.name, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- app em primeiro plano

    private fun onForegroundChanged(pkg: String) {
        val sm = AppRuntime.state.state
        if (sm != RunState.RUNNING && sm != RunState.PAUSED) return
        if (editor.isShown) return

        val gamePkg = store.activePackage
        if (settings.autoLoadProfile && pkg != gamePkg && pkg in knownPackages) {
            // Abriu outro jogo que tem perfil: troca de perfil.
            stateManager.releaseAllControls()
            store.activePackage = pkg
            loadProfile()
            showPlayOverlay()
            return
        }
        if (gamePkg == null) return
        if (pkg == gamePkg) {
            if (hiddenByLeaving) showPlayOverlay()
            return
        }
        // Saiu do jogo: nada pode ficar preso.
        stateManager.releaseAllControls()
        if (pkg in IGNORED_PACKAGES) return
        if (SystemClock.elapsedRealtime() - startedAt < GRACE_MS) return // transições na abertura do jogo
        when (settings.leaveBehavior) {
            1 -> if (sm == RunState.RUNNING) {
                hidePlayOverlay()
                hiddenByLeaving = true
            }
            2 -> shutdown()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotação: libera tudo e recarrega o perfil da nova orientação. Edição em andamento é descartada.
        stateManager.releaseAllControls()
        val sm = AppRuntime.state.state
        if (sm != RunState.RUNNING && sm != RunState.PAUSED) return
        editor.hide()
        loadProfile()
        if (sm == RunState.RUNNING) showPlayOverlay() else syncBubble()
    }

    // ---------------------------------------------------------------- util

    private fun currentGeometry(): TouchGeometry {
        val s = Screen.size(this)
        return profile.geometry(s.width, s.height, resources.displayMetrics.density)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW),
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_launcher_foreground)
        fun action(title: Int, act: String, code: Int) = Notification.Action.Builder(
            icon, getString(title),
            PendingIntent.getService(
                this, code, Intent(this, OverlayService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        ).build()
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.notif_title, getString(R.string.app_name)))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .addAction(action(R.string.notif_action_stop, ACTION_STOP, 1))
            .addAction(action(R.string.notif_action_toggle, ACTION_TOGGLE, 2))
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.wasdoverlay.action.STOP"
        const val ACTION_TOGGLE = "com.wasdoverlay.action.TOGGLE"
        const val ACTION_EDIT = "com.wasdoverlay.action.EDIT"
        private const val CHANNEL_ID = "overlay_active"
        private const val NOTIF_ID = 1
        private const val GRACE_MS = 3000L
        private val IGNORED_PACKAGES = setOf("com.android.systemui")
    }
}
