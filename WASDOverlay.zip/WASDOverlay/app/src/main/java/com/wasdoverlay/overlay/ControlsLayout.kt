package com.wasdoverlay.overlay

import com.wasdoverlay.model.ControlSpec
import com.wasdoverlay.model.Profile
import com.wasdoverlay.model.PxRect
import kotlin.math.max

data class PlacedControl(val spec: ControlSpec, val rect: PxRect)

/** Posições dos botões em pixels de tela + caixa que os envolve (tamanho da janela do overlay). */
class ControlsLayout private constructor(val placed: List<PlacedControl>, val bounds: PxRect) {

    /** Coordenadas absolutas da tela (usado para deslizar o dedo de um botão para outro). */
    fun hitTestScreen(x: Float, y: Float): PlacedControl? = placed.lastOrNull { it.rect.contains(x, y) }

    /** Coordenadas relativas ao canto superior esquerdo da caixa que envolve todos os botões. */
    fun hitTest(xInWindow: Float, yInWindow: Float): PlacedControl? {
        val x = xInWindow + bounds.left
        val y = yInWindow + bounds.top
        return placed.lastOrNull { it.rect.contains(x, y) }
    }

    companion object {
        fun compute(profile: Profile, screenW: Int, screenH: Int, density: Float): ControlsLayout? {
            if (profile.controls.isEmpty() || screenW <= 0 || screenH <= 0) return null
            val placed = profile.controls.map { spec ->
                val size = spec.sizeDp * density * profile.overlayScale
                val left = (spec.xFrac * screenW).coerceIn(0f, max(0f, screenW - size))
                val top = (spec.yFrac * screenH).coerceIn(0f, max(0f, screenH - size))
                PlacedControl(spec, PxRect(left, top, left + size, top + size))
            }
            val bounds = PxRect(
                placed.minOf { it.rect.left },
                placed.minOf { it.rect.top },
                placed.maxOf { it.rect.right },
                placed.maxOf { it.rect.bottom },
            )
            return ControlsLayout(placed, bounds)
        }
    }
}
