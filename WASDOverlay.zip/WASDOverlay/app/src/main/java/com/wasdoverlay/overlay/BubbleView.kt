package com.wasdoverlay.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.wasdoverlay.R
import kotlin.math.hypot

/**
 * Botão flutuante do menu. Recolhido: bolinha "≡". Expandido: Ocultar/Mostrar, Editar, Perfil
 * (troca de jogo) e PARAR (emergência). Arrastável. Alvos de toque de 48 dp.
 */
@SuppressLint("ViewConstructor")
class BubbleView(
    context: Context,
    private val onToggle: () -> Unit,
    private val onEdit: () -> Unit,
    private val onSwitch: () -> Unit,
    private val onStop: () -> Unit,
    private val onResize: () -> Unit,
    private val onDrag: (Float, Float) -> Unit,
) : View(context) {

    private val d = context.resources.displayMetrics.density
    private val circle = 48f * d
    private val chipW = 64f * d
    private val gap = 6f * d
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var expanded = false
        private set

    var controlsHidden = false
        set(value) { field = value; invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val rects = List(4) { RectF() }
    private val circleRect = RectF()

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        contentDescription = context.getString(R.string.bubble_description)
    }

    fun desiredWidth(): Int = (if (expanded) circle + gap + 4 * chipW + 3 * gap else circle).toInt()
    fun desiredHeight(): Int = circle.toInt()

    private fun labels() = listOf(
        context.getString(if (controlsHidden) R.string.bubble_show else R.string.bubble_hide),
        context.getString(R.string.bubble_edit),
        context.getString(R.string.bubble_profile),
        context.getString(R.string.bubble_stop),
    )

    override fun onDraw(canvas: Canvas) {
        circleRect.set(0f, 0f, circle, circle)
        fill.color = 0xCC303030.toInt()
        canvas.drawCircle(circle / 2f, circle / 2f, circle / 2f, fill)
        KeyDrawer.drawCentered(canvas, if (expanded) "×" else "≡", circle / 2f, circle / 2f, circle * 0.6f, 24f * d, text)
        if (!expanded) return
        var x = circle + gap
        val names = labels()
        rects.forEachIndexed { i, r ->
            r.set(x, 0f, x + chipW, circle)
            fill.color = if (i == 3) 0xEED32F2F.toInt() else 0xEE303030.toInt()
            canvas.drawRoundRect(r, 12f * d, 12f * d, fill)
            KeyDrawer.drawCentered(canvas, names[i], r.centerX(), r.centerY(), chipW * 0.9f, 13f * d, text)
            x += chipW + gap
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = e.rawX; lastY = e.rawY; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) moved = true
                if (moved) onDrag(e.rawX - lastX, e.rawY - lastY)
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> if (!moved) tap(e.x, e.y)
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        if (!expanded) {
            setExpanded(true)
            return
        }
        when {
            circleRect.contains(x, y) -> setExpanded(false)
            rects[0].contains(x, y) -> { setExpanded(false); onToggle() }
            rects[1].contains(x, y) -> { setExpanded(false); onEdit() }
            rects[2].contains(x, y) -> onSwitch()
            rects[3].contains(x, y) -> onStop()
        }
    }

    override fun performClick(): Boolean {
        setExpanded(!expanded)
        return true
    }

    private fun setExpanded(value: Boolean) {
        expanded = value
        onResize()
        invalidate()
    }
}
