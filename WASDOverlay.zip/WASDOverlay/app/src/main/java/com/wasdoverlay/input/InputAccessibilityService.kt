package com.wasdoverlay.input

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Serviço de acessibilidade mínimo: só despacha gestos (canPerformGestures) e guarda o NOME DO
 * PACOTE da janela em primeiro plano. Não lê conteúdo da tela nem texto digitado.
 */
class InputAccessibilityService : AccessibilityService() {

    @Volatile
    var engine: JoystickGestureEngine? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        engine = JoystickGestureEngine(this)
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        foregroundPackage = pkg
        foregroundListener?.invoke(pkg)
    }

    override fun onInterrupt() {
        engine?.releaseAll()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdownEngine()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdownEngine()
        super.onDestroy()
    }

    private fun shutdownEngine() {
        engine?.releaseAll()
        engine = null
        if (instance === this) instance = null
    }

    companion object {
        @Volatile
        var instance: InputAccessibilityService? = null
            private set

        /** Último pacote que abriu uma janela (exceto este app). Base para perfis por jogo. */
        @Volatile
        var foregroundPackage: String? = null
            private set

        /** Chamado na thread principal quando outra janela de app vai para o primeiro plano. */
        @Volatile
        var foregroundListener: ((String) -> Unit)? = null
    }
}
