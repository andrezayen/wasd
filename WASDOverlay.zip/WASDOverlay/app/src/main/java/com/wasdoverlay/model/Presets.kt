package com.wasdoverlay.model

enum class Preset(val title: String, val extras: List<ControlAction>) {
    BASIC("WASD básico", emptyList()),
    WASD_SPACE("WASD + Space", listOf(ControlAction.SPACE)),
    WASD_SPACE_SHIFT("WASD + Space + Shift", listOf(ControlAction.SPACE, ControlAction.SHIFT)),
    FPS(
        "FPS",
        listOf(
            ControlAction.SPACE, ControlAction.SHIFT, ControlAction.CTRL,
            ControlAction.E, ControlAction.Q, ControlAction.R, ControlAction.F,
        ),
    ),
    MOBA(
        "MOBA",
        listOf(
            ControlAction.Q, ControlAction.E, ControlAction.R, ControlAction.F,
            ControlAction.N1, ControlAction.N2, ControlAction.N3, ControlAction.N4,
        ),
    ),
}

/** Nenhum preset garante funcionar em todos os jogos: os pontos de toque precisam ser calibrados. */
object Presets {
    const val DEFAULT_SIZE_DP = 56f

    fun build(
        preset: Preset,
        packageName: String?,
        name: String,
        orientation: String,
        sizeDp: Float = DEFAULT_SIZE_DP,
    ): Profile {
        val o = if (orientation == Orientation.PORTRAIT) Orientation.PORTRAIT else Orientation.LANDSCAPE
        val landscape = o == Orientation.LANDSCAPE
        val joystick = if (landscape) JoystickCalibration(0.12f, 0.72f, 50f) else JoystickCalibration(0.85f, 0.90f, 50f)
        val cluster = if (landscape) {
            listOf(
                ControlSpec("w", ControlAction.W, "W", 0.300f, 0.40f, sizeDp),
                ControlSpec("a", ControlAction.A, "A", 0.225f, 0.57f, sizeDp),
                ControlSpec("s", ControlAction.S, "S", 0.300f, 0.57f, sizeDp),
                ControlSpec("d", ControlAction.D, "D", 0.375f, 0.57f, sizeDp),
            )
        } else {
            listOf(
                ControlSpec("w", ControlAction.W, "W", 0.40f, 0.55f, sizeDp),
                ControlSpec("a", ControlAction.A, "A", 0.22f, 0.64f, sizeDp),
                ControlSpec("s", ControlAction.S, "S", 0.40f, 0.64f, sizeDp),
                ControlSpec("d", ControlAction.D, "D", 0.58f, 0.64f, sizeDp),
            )
        }
        val extras = preset.extras.mapIndexed { i, a ->
            val (x, y) = extraPosition(i, landscape)
            ControlSpec(a.name.lowercase(), a, a.symbol, x, y, sizeDp)
        }
        val targets = preset.extras.mapIndexed { i, a -> a to defaultTarget(i, landscape) }.toMap()
        return Profile(Profile.idFor(packageName, o), name, packageName, o, joystick, cluster + extras, targets)
    }

    /** Posição do i-ésimo botão extra (ao lado do WASD). */
    fun extraPosition(i: Int, landscape: Boolean): Pair<Float, Float> =
        if (landscape) {
            Pair(0.45f + 0.075f * (i / 2), if (i % 2 == 0) 0.40f else 0.57f)
        } else {
            Pair(0.08f + 0.17f * (i % 5), 0.75f + 0.09f * (i / 5))
        }

    /** Ponto de toque inicial (placeholder) no jogo; o usuário arrasta cada marcador no editor. */
    fun defaultTarget(i: Int, landscape: Boolean): FracPoint =
        if (landscape) {
            FracPoint(0.80f + 0.04f * (i % 5), 0.20f + 0.12f * (i / 5))
        } else {
            FracPoint(0.15f + 0.15f * (i % 5), 0.25f + 0.10f * (i / 5))
        }
}
