package com.wasdoverlay.control

import java.util.concurrent.atomic.AtomicInteger

/** Estado compartilhado entre a Activity e o serviço (mesmo processo). */
object AppRuntime {
    val state = RunStateMachine()

    /** true enquanto o processo privilegiado (Shizuku ou su) está vivo. */
    @Volatile
    var privilegedActive: Boolean = false

    /** "shizuku" ou "root": quem está fornecendo o acesso privilegiado agora. */
    @Volatile
    var privilegedSource: String = ""

    /** Quantos gestos de acessibilidade o sistema cancelou (toques reais cancelam gestos injetados). */
    val gestureCancels = AtomicInteger(0)
}
