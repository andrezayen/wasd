package com.wasdoverlay.storage

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import com.wasdoverlay.BuildConfig

/** Preferências do app (somente locais). */
class AppSettings(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("wasd_settings", Context.MODE_PRIVATE)

    var themeMode: String // "system" | "light" | "dark"
        get() = p.getString("theme", "system") ?: "system"
        set(v) { p.edit().putString("theme", v).apply() }

    val nightMode: Int
        get() = when (themeMode) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }

    var vibration: Boolean
        get() = p.getBoolean("vibration", false)
        set(v) { p.edit().putBoolean("vibration", v).apply() }

    var sound: Boolean
        get() = p.getBoolean("sound", false)
        set(v) { p.edit().putBoolean("sound", v).apply() }

    var opacityPercent: Int
        get() = p.getInt("opacity", 35)
        set(v) { p.edit().putInt("opacity", v.coerceIn(10, 100)).apply() }

    var defaultSizeDp: Int
        get() = p.getInt("size_dp", 56)
        set(v) { p.edit().putInt("size_dp", v.coerceIn(32, 96)).apply() }

    var showBubble: Boolean
        get() = p.getBoolean("bubble", true)
        set(v) { p.edit().putBoolean("bubble", v).apply() }

    var autoLoadProfile: Boolean
        get() = p.getBoolean("auto_load", true)
        set(v) { p.edit().putBoolean("auto_load", v).apply() }

    /** 0 = manter controles, 1 = ocultar, 2 = parar o serviço. */
    var leaveBehavior: Int
        get() = p.getInt("leave", 0)
        set(v) { p.edit().putInt("leave", v).apply() }

    /** "accessibility" (padrão) | "privileged_keys" (teclas reais) | "privileged_touch" (toques injetados). */
    var inputMode: String
        get() = p.getString("input_mode", "accessibility") ?: "accessibility"
        set(v) { p.edit().putString("input_mode", v).apply() }

    /** Origem do acesso privilegiado: "auto" (Shizuku, depois su) | "shizuku" | "root". */
    var privilegeSource: String
        get() = p.getString("privilege_source", "auto") ?: "auto"
        set(v) { p.edit().putString("privilege_source", v).apply() }

    /** Força da vibração, 10..100 (duração e amplitude). */
    var vibrationStrength: Int
        get() = p.getInt("vibration_strength", 50)
        set(v) { p.edit().putInt("vibration_strength", v.coerceIn(10, 100)).apply() }

    var diagnosticLogs: Boolean
        get() = p.getBoolean("logs", BuildConfig.DEBUG)
        set(v) { p.edit().putBoolean("logs", v).apply() }

    var onboardingDone: Boolean
        get() = p.getBoolean("onboarding_done", false)
        set(v) { p.edit().putBoolean("onboarding_done", v).apply() }
}
