package com.wasdoverlay.storage

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.ControlSpec
import com.wasdoverlay.model.FracPoint
import com.wasdoverlay.model.JoystickCalibration
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.model.Profile
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Formato versionado (schemaVersion) de perfis. Entrada inválida => null (nunca lança). */
object ProfileJson {
    const val SCHEMA_VERSION = 1

    fun toJson(profiles: List<Profile>): String {
        val arr = JSONArray()
        profiles.forEach { arr.put(toObj(it)) }
        return JSONObject().put("schemaVersion", SCHEMA_VERSION).put("profiles", arr).toString(2)
    }

    fun fromJson(text: String): List<Profile>? = try {
        val root = JSONObject(text)
        if (root.optInt("schemaVersion", -1) != SCHEMA_VERSION) {
            null
        } else {
            val arr = root.getJSONArray("profiles")
            (0 until arr.length()).mapNotNull { i ->
                try { parseProfile(arr.getJSONObject(i)) } catch (_: JSONException) { null }
            }
        }
    } catch (_: JSONException) {
        null
    }

    private fun toObj(p: Profile): JSONObject {
        val controls = JSONArray()
        p.controls.forEach { c ->
            controls.put(
                JSONObject().put("id", c.id).put("action", c.action.name).put("label", c.label)
                    .put("x", c.xFrac.toDouble()).put("y", c.yFrac.toDouble()).put("sizeDp", c.sizeDp.toDouble())
                    .put("opacity", c.opacity.toDouble()).put("border", c.border)
                    .put("corner", c.corner.toDouble()).put("showLabel", c.showLabel),
            )
        }
        val targets = JSONArray()
        p.targets.forEach { (action, pt) ->
            targets.put(JSONObject().put("action", action.name).put("x", pt.x.toDouble()).put("y", pt.y.toDouble()))
        }
        val customKeys = JSONArray()
        p.customKeys.forEach { (action, key) ->
            customKeys.put(JSONObject().put("action", action.name).put("key", key))
        }
        return JSONObject()
            .put("id", p.id).put("name", p.name)
            .put("packageName", p.packageName ?: JSONObject.NULL)
            .put("orientation", p.orientation)
            .put("overlayScale", p.overlayScale.toDouble())
            .put(
                "joystick",
                JSONObject().put("x", p.joystick.centerXFrac.toDouble())
                    .put("y", p.joystick.centerYFrac.toDouble())
                    .put("radiusDp", p.joystick.radiusDp.toDouble()),
            )
            .put("controls", controls)
            .put("targets", targets)
            .put("customKeys", customKeys)
    }

    private fun parseProfile(o: JSONObject): Profile? {
        val id = o.getString("id")
        if (id.isBlank()) return null
        val j = o.getJSONObject("joystick")
        val arr = o.getJSONArray("controls")
        val controls = (0 until arr.length()).mapNotNull { i ->
            val c = arr.getJSONObject(i)
            val action = actionOrNull(c.getString("action")) ?: return@mapNotNull null
            ControlSpec(
                id = c.getString("id"),
                action = action,
                label = c.getString("label"),
                xFrac = c.getDouble("x").toFloat().coerceIn(0f, 1f),
                yFrac = c.getDouble("y").toFloat().coerceIn(0f, 1f),
                sizeDp = c.getDouble("sizeDp").toFloat().coerceIn(24f, 120f),
                opacity = c.optDouble("opacity", -1.0).toFloat().let { if (it < 0f) -1f else it.coerceIn(0.1f, 1f) },
                border = c.optBoolean("border", true),
                corner = c.optDouble("corner", 0.2).toFloat().coerceIn(0f, 0.5f),
                showLabel = c.optBoolean("showLabel", true),
            )
        }
        if (controls.isEmpty()) return null
        val targets = LinkedHashMap<ControlAction, FracPoint>()
        val tArr = o.optJSONArray("targets")
        if (tArr != null) {
            for (i in 0 until tArr.length()) {
                val t = tArr.getJSONObject(i)
                val action = actionOrNull(t.getString("action")) ?: continue
                targets[action] = FracPoint(
                    t.getDouble("x").toFloat().coerceIn(0f, 1f),
                    t.getDouble("y").toFloat().coerceIn(0f, 1f),
                )
            }
        }
        val customKeys = LinkedHashMap<ControlAction, Int>()
        val kArr = o.optJSONArray("customKeys")
        if (kArr != null) {
            for (i in 0 until kArr.length()) {
                val k = kArr.getJSONObject(i)
                val action = actionOrNull(k.getString("action")) ?: continue
                val key = k.getInt("key")
                if (key in 1..300) customKeys[action] = key
            }
        }
        val orientation = if (o.optString("orientation") == Orientation.PORTRAIT) Orientation.PORTRAIT else Orientation.LANDSCAPE
        return Profile(
            id = id,
            name = o.getString("name"),
            packageName = if (o.isNull("packageName")) null else o.getString("packageName"),
            orientation = orientation,
            joystick = JoystickCalibration(
                j.getDouble("x").toFloat().coerceIn(0f, 1f),
                j.getDouble("y").toFloat().coerceIn(0f, 1f),
                j.getDouble("radiusDp").toFloat().coerceIn(10f, 300f),
            ),
            controls = controls,
            targets = targets,
            customKeys = customKeys,
            overlayScale = o.optDouble("overlayScale", 1.0).toFloat().coerceIn(0.5f, 2f),
        )
    }

    private fun actionOrNull(name: String): ControlAction? =
        try { ControlAction.valueOf(name) } catch (_: IllegalArgumentException) { null }
}
