package com.wasdoverlay.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Vibração curta com intensidade configurável (10..100): amplitude quando o aparelho permite, senão só a duração. */
class Haptics(context: Context, private val strengthPercent: Int) {
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
        context.getSystemService(VibratorManager::class.java)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun tick() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val strength = strengthPercent.coerceIn(10, 100)
        val ms = 8L + strength / 4
        val effect = if (v.hasAmplitudeControl()) {
            VibrationEffect.createOneShot(ms, (strength * 255 / 100).coerceIn(1, 255))
        } else {
            VibrationEffect.createOneShot(ms + 10, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        v.vibrate(effect)
    }
}
