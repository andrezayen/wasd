package com.wasdoverlay.model

/**
 * Ações dos botões. Movimento (W/A/S/D) vira deslocamento no joystick virtual do jogo;
 * as demais viram um TOQUE SUSTENTADO num ponto da tela do jogo (ex.: botão de pulo).
 * O Android não permite enviar teclas reais a outro app sem root.
 */
enum class ControlAction(val symbol: String, val dx: Int = 0, val dy: Int = 0) {
    W("W", 0, -1), A("A", -1, 0), S("S", 0, 1), D("D", 1, 0),
    SPACE("SPACE"), SHIFT("SHIFT"), CTRL("CTRL"), ALT("ALT"), TAB("TAB"), ESC("ESC"), ENTER("ENTER"),
    E("E"), Q("Q"), R("R"), F("F"),
    N1("1"), N2("2"), N3("3"), N4("4"), N5("5"), N6("6"), N7("7"), N8("8"), N9("9"), N0("0"),
    CUSTOM1("C1"), CUSTOM2("C2"), CUSTOM3("C3"), CUSTOM4("C4");

    val isMovement: Boolean get() = dx != 0 || dy != 0
}
