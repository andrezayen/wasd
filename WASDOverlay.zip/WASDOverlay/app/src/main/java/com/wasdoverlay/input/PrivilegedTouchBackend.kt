package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.Point
import com.wasdoverlay.model.TouchGeometry
import java.util.EnumSet
import kotlin.math.roundToInt

/**
 * Toques injetados pelo processo privilegiado (MotionEvent multi-ponteiro, sem encadear gestos e
 * sem serem cancelados por toques reais, ao contrário do dispatchGesture).
 */
class PrivilegedTouchBackend(
    private val link: InjectorLink,
    private val geometryProvider: () -> TouchGeometry?,
) : InputBackend {

    private val held: MutableSet<ControlAction> = EnumSet.noneOf(ControlAction::class.java)
    private var sent: Map<String, Point> = emptyMap()

    override val isAvailable: Boolean get() = link.isAlive

    override fun press(action: ControlAction) { held.add(action); push() }
    override fun release(action: ControlAction) { held.remove(action); push() }

    override fun releaseAll() {
        held.clear()
        sent = emptyMap()
        link.send("RA")
    }

    private fun push() {
        if (!link.isAlive) { sent = emptyMap(); return }
        val g = geometryProvider()
        val plan = if (g == null || held.isEmpty()) emptyMap() else TouchTargets.compute(held.toSet(), g)
        for ((id, lane) in plan) {
            val prev = sent[id]
            if (prev == null) link.send(line(id, lane.start))
            if (prev != lane.target && (prev != null || lane.start != lane.target)) link.send(line(id, lane.target))
        }
        for (id in sent.keys - plan.keys) link.send("R $id")
        sent = plan.mapValues { it.value.target }
    }

    private fun line(id: String, p: Point) = "T $id ${p.x.roundToInt()} ${p.y.roundToInt()}"
}
