package com.wasdoverlay.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.wasdoverlay.R
import com.wasdoverlay.control.AppRuntime
import com.wasdoverlay.control.RunState
import com.wasdoverlay.input.InputAccessibilityService
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.service.OverlayService
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.storage.ProfileStore
import com.wasdoverlay.util.Screen
import com.wasdoverlay.util.Ui

class MainActivity : AppCompatActivity() {

    private lateinit var txtOverlay: TextView
    private lateinit var txtInput: TextView
    private lateinit var txtState: TextView
    private lateinit var txtGame: TextView
    private lateinit var txtProfile: TextView
    private val store by lazy { ProfileStore(this) }
    private var askedNotifications = false
    private var pendingAfterPermission: (() -> Unit)? = null

    private val stateListener: (RunState) -> Unit = { runOnUiThread { refreshStatus() } }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            pendingAfterPermission?.invoke()
            pendingAfterPermission = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(findViewById<View>(R.id.root))

        txtOverlay = findViewById(R.id.txtOverlay)
        txtInput = findViewById(R.id.txtInput)
        txtState = findViewById(R.id.txtState)
        txtGame = findViewById(R.id.txtGame)
        txtProfile = findViewById(R.id.txtProfile)

        click(R.id.btnOverlayPermission) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        click(R.id.btnAccessibility) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        click(R.id.btnPickGame) { startActivity(Intent(this, GameListActivity::class.java)) }
        click(R.id.btnEdit) { launchGame(editMode = true) }
        click(R.id.btnPlay) { launchGame(editMode = false) }
        click(R.id.btnStop) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }
        click(R.id.btnProfiles) { startActivity(Intent(this, ProfilesActivity::class.java)) }
        click(R.id.btnSettings) { startActivity(Intent(this, SettingsActivity::class.java)) }
        click(R.id.btnDiagnostics) { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        click(R.id.btnHelp) { startActivity(Intent(this, HelpActivity::class.java)) }

        store.ensureDefault(getString(R.string.default_profile_name))
        if (!AppSettings(this).onboardingDone) startActivity(Intent(this, OnboardingActivity::class.java))
    }

    private fun click(id: Int, action: () -> Unit) = findViewById<View>(id).setOnClickListener { action() }

    override fun onStart() {
        super.onStart()
        AppRuntime.state.addListener(stateListener)
    }

    override fun onStop() {
        AppRuntime.state.removeListener(stateListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    /** Escolher jogo → (editar: posicionar/calibrar/salvar) → iniciar e jogar. */
    private fun launchGame(editMode: Boolean) {
        val pkg = store.activePackage
        withOverlayReady {
            val i = Intent(this, OverlayService::class.java)
            if (editMode) i.action = OverlayService.ACTION_EDIT
            startForegroundService(i)
            if (pkg != null) {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    startActivity(launch)
                } else {
                    Toast.makeText(this, R.string.err_game_not_launchable, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun withOverlayReady(block: () -> Unit) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.err_overlay_permission, Toast.LENGTH_LONG).show()
            return
        }
        val needsNotif = Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsNotif && !askedNotifications) {
            askedNotifications = true
            pendingAfterPermission = block
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            block()
        }
    }

    private fun refreshStatus() {
        txtOverlay.setText(if (Settings.canDrawOverlays(this)) R.string.status_overlay_ok else R.string.status_overlay_needed)
        txtInput.setText(if (InputAccessibilityService.instance != null) R.string.status_input_ok else R.string.status_input_off)
        txtState.text = getString(R.string.status_state, AppRuntime.state.state.name)
        val profile = store.resolveActive(Screen.orientation(this), getString(R.string.default_profile_name))
        txtGame.text = if (store.activePackage != null) {
            getString(R.string.status_game, profile.name)
        } else {
            getString(R.string.status_game_none)
        }
        val orientationName = getString(
            if (profile.orientation == Orientation.PORTRAIT) R.string.orientation_portrait else R.string.orientation_landscape,
        )
        txtProfile.text = getString(R.string.status_profile, profile.name, orientationName)
    }
}
