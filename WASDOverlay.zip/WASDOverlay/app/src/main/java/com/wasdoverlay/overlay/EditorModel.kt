package com.wasdoverlay.overlay

import com.wasdoverlay.model.ControlAction
import com.wasdoverlay.model.ControlSpec
import com.wasdoverlay.model.FracPoint
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.model.Presets
import com.wasdoverlay.model.Profile

/** Estado puro do editor: botões, alvos de toque, joystick e seleção. */
class EditorModel(initial: Profile) {
    var profile: Profile = initial
        private set

    var selected: Int = -1
        private set

    fun select(index: Int) { selected = if (index in profile.controls.indices) index else -1 }

    fun moveControl(index: Int, xFrac: Float, yFrac: Float) {
        if (index !in profile.controls.indices) return
        val list = profile.controls.toMutableList()
        list[index] = list[index].copy(xFrac = xFrac.coerceIn(0f, 1f), yFrac = yFrac.coerceIn(0f, 1f))
        profile = profile.copy(controls = list)
    }

    fun moveTarget(action: ControlAction, xFrac: Float, yFrac: Float) {
        profile = profile.copy(targets = profile.targets + (action to FracPoint(xFrac.coerceIn(0f, 1f), yFrac.coerceIn(0f, 1f))))
    }

    fun moveJoystick(xFrac: Float, yFrac: Float) {
        profile = profile.copy(
            joystick = profile.joystick.copy(centerXFrac = xFrac.coerceIn(0f, 1f), centerYFrac = yFrac.coerceIn(0f, 1f)),
        )
    }

    fun adjustRadius(deltaDp: Float) {
        val j = profile.joystick
        profile = profile.copy(joystick = j.copy(radiusDp = (j.radiusDp + deltaDp).coerceIn(20f, 150f)))
    }

    fun adjustSize(deltaDp: Float) {
        profile = profile.copy(
            controls = profile.controls.map { it.copy(sizeDp = (it.sizeDp + deltaDp).coerceIn(32f, 96f)) },
        )
    }

    /** Escala geral dos botões do perfil (0.5..2). */
    fun adjustScale(delta: Float) {
        profile = profile.copy(overlayScale = (profile.overlayScale + delta).coerceIn(0.5f, 2f))
    }

    /** Botões afetados pelo estilo: o selecionado, ou todos se nenhum estiver selecionado. */
    private fun affected(): List<Int> =
        if (selected in profile.controls.indices) listOf(selected) else profile.controls.indices.toList()

    private fun restyle(transform: (ControlSpec) -> ControlSpec) {
        val idx = affected().toSet()
        profile = profile.copy(controls = profile.controls.mapIndexed { i, c -> if (i in idx) transform(c) else c })
    }

    fun adjustOpacity(delta: Float) = restyle { c ->
        val base = if (c.opacity < 0f) 0.35f else c.opacity
        c.copy(opacity = (base + delta).coerceIn(0.1f, 1f))
    }

    fun adjustCorner(delta: Float) = restyle { it.copy(corner = (it.corner + delta).coerceIn(0f, 0.5f)) }

    fun toggleBorder() {
        val value = !(profile.controls.getOrNull(affected().first())?.border ?: true)
        restyle { it.copy(border = value) }
    }

    fun toggleLabel() {
        val value = !(profile.controls.getOrNull(affected().first())?.showLabel ?: true)
        restyle { it.copy(showLabel = value) }
    }

    /**
     * Captura de toque: o ponto tocado vira o alvo da ação do botão selecionado (se for uma ação
     * de toque) ou o centro do joystick do jogo (se for movimento ou nada estiver selecionado).
     */
    fun captureAt(xFrac: Float, yFrac: Float) {
        val action = profile.controls.getOrNull(selected)?.action
        if (action != null && !action.isMovement) moveTarget(action, xFrac, yFrac) else moveJoystick(xFrac, yFrac)
    }

    /** Ações que ainda não têm botão (para a paleta "+ Botão"). */
    fun availableActions(): List<ControlAction> {
        val used = profile.controls.map { it.action }.toSet()
        return ControlAction.entries.filter { it !in used }
    }

    /** @return true se criou; se a ação já existe, apenas a seleciona. */
    fun addControl(action: ControlAction): Boolean {
        val existing = profile.controls.indexOfFirst { it.action == action }
        if (existing >= 0) {
            selected = existing
            return false
        }
        val landscape = profile.orientation != Orientation.PORTRAIT
        val extraIdx = profile.controls.count { !it.action.isMovement }
        val (x, y) = Presets.extraPosition(extraIdx, landscape)
        val size = profile.controls.firstOrNull()?.sizeDp ?: Presets.DEFAULT_SIZE_DP
        val spec = ControlSpec(uniqueId(action.name.lowercase()), action, action.symbol, x, y, size)
        val targets = if (!action.isMovement && action !in profile.targets) {
            profile.targets + (action to Presets.defaultTarget(extraIdx, landscape))
        } else {
            profile.targets
        }
        profile = profile.copy(controls = profile.controls + spec, targets = targets)
        selected = profile.controls.lastIndex
        return true
    }

    /** Não permite apagar o último botão (um perfil sem botões seria inválido). */
    fun removeSelected(): Boolean {
        if (selected !in profile.controls.indices || profile.controls.size <= 1) return false
        val removed = profile.controls[selected]
        val rest = profile.controls.filterIndexed { i, _ -> i != selected }
        val targets = if (rest.none { it.action == removed.action }) profile.targets - removed.action else profile.targets
        profile = profile.copy(controls = rest, targets = targets)
        selected = -1
        return true
    }

    /** Duplica o botão selecionado; CUSTOMn duplica para o próximo CUSTOM livre. */
    fun duplicateSelected(): Boolean {
        val src = profile.controls.getOrNull(selected) ?: return false
        val used = profile.controls.map { it.action }.toSet()
        val action = if (src.action.name.startsWith("CUSTOM")) {
            ControlAction.entries.firstOrNull { it.name.startsWith("CUSTOM") && it !in used } ?: src.action
        } else {
            src.action
        }
        val copy = src.copy(
            id = uniqueId(action.name.lowercase()),
            action = action,
            label = if (action != src.action) action.symbol else src.label,
            xFrac = (src.xFrac + 0.03f).coerceAtMost(1f),
            yFrac = (src.yFrac + 0.03f).coerceAtMost(1f),
        )
        var targets = profile.targets
        if (!action.isMovement && action !in targets) {
            val base = targets[src.action] ?: Presets.defaultTarget(profile.controls.size, profile.orientation != Orientation.PORTRAIT)
            targets = targets + (action to FracPoint((base.x + 0.03f).coerceAtMost(1f), (base.y + 0.03f).coerceAtMost(1f)))
        }
        profile = profile.copy(controls = profile.controls + copy, targets = targets)
        selected = profile.controls.lastIndex
        return true
    }

    /**
     * O toque despachado pela acessibilidade atinge a janela que estiver no ponto; se o círculo do
     * joystick cruzar os botões, o "dedo" cairia no próprio overlay.
     */
    fun joystickOverlapsControls(screenW: Int, screenH: Int, density: Float): Boolean {
        val layout = ControlsLayout.compute(profile, screenW, screenH, density) ?: return false
        val j = profile.joystick.toPx(screenW, screenH, density)
        return layout.placed.any { p ->
            val nx = j.center.x.coerceIn(p.rect.left, p.rect.right)
            val ny = j.center.y.coerceIn(p.rect.top, p.rect.bottom)
            val dx = j.center.x - nx
            val dy = j.center.y - ny
            dx * dx + dy * dy <= j.radius * j.radius
        }
    }

    private fun uniqueId(base: String): String {
        var id = base
        var n = 2
        while (profile.controls.any { it.id == id }) {
            id = "$base$n"
            n++
        }
        return id
    }
}
