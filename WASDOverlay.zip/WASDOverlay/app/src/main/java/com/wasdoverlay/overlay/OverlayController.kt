package com.wasdoverlay.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import com.wasdoverlay.control.ControlStateManager
import com.wasdoverlay.model.Profile
import com.wasdoverlay.util.Screen
import kotlin.math.roundToInt

/**
 * Overlay de jogo: UMA janela por botão, do tamanho exato dele. Assim as áreas entre os botões
 * (e todo o resto da tela) continuam entregando o toque ao jogo.
 */
class OverlayController(
    private val context: Context,
    private val manager: ControlStateManager,
) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private val views = ArrayList<ButtonView>()

    val isShown: Boolean get() = views.isNotEmpty()

    /** @return false se não foi possível exibir (sem permissão, sem controles etc.). */
    fun show(profile: Profile, style: OverlayStyle = OverlayStyle()): Boolean {
        hide()
        val size = Screen.size(context)
        val layout = ControlsLayout.compute(
            profile, size.width, size.height, context.resources.displayMetrics.density,
        ) ?: return false
        layout.placed.forEachIndexed { i, p ->
            val v = ButtonView(context, i, p, layout, manager, style)
            val lp = WindowManager.LayoutParams(
                p.rect.width.roundToInt(),
                p.rect.height.roundToInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = p.rect.left.roundToInt()
                y = p.rect.top.roundToInt()
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            try {
                windowManager.addView(v, lp)
                views += v
            } catch (e: RuntimeException) { // BadTokenException quando falta a permissão
                hide()
                return false
            }
        }
        return true
    }

    fun hide() {
        if (views.isEmpty()) return
        val copy = views.toList()
        views.clear()
        manager.releaseAllControls()
        copy.forEach {
            try {
                windowManager.removeViewImmediate(it)
            } catch (_: IllegalArgumentException) {
                // já removida
            }
        }
    }

    fun refresh() {
        views.forEach { it.invalidate() }
    }
}
