package com.wasdoverlay.root

import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * PROCESSO AUXILIAR OPCIONAL (só roda se o usuário escolher root e o `su` permitir).
 * Lançado como `su -c "CLASSPATH=<apk> app_process /system/bin com.wasdoverlay.root.RootInjector"`.
 * Lê comandos de stdin (ver [InjectorCore]); `Q` ou stdin fechado = sair soltando tudo.
 */
object RootInjector {
    @JvmStatic
    fun main(args: Array<String>) {
        try { Looper.prepareMainLooper() } catch (_: Throwable) { }
        val core = InjectorCore()
        Runtime.getRuntime().addShutdownHook(Thread { core.releaseAll() })
        val reader = BufferedReader(InputStreamReader(System.`in`))
        while (true) {
            val line = reader.readLine() ?: break
            if (line.trim() == "Q") break
            core.handle(line)
        }
        core.releaseAll()
    }
}
