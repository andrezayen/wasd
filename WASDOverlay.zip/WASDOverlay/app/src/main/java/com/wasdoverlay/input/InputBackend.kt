package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction

/**
 * Contrato do "sistema de entrada". O overlay DESENHA e detecta toques; o backend TENTA produzir
 * a ação correspondente. Se não houver backend disponível, o overlay continua funcionando
 * visualmente ([isAvailable] = false) e press/release viram no-ops seguros.
 */
interface InputBackend {
    val isAvailable: Boolean
    fun press(action: ControlAction)
    fun release(action: ControlAction)
    fun releaseAll()
}
