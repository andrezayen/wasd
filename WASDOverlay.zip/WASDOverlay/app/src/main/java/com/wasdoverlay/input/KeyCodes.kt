package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction

/** Valores de android.view.KeyEvent.KEYCODE_* (constantes numéricas estáveis; mantém a lógica testável na JVM). */
object KeyCodes {
    private val map: Map<ControlAction, Int> = mapOf(
        ControlAction.W to 51, ControlAction.A to 29, ControlAction.S to 47, ControlAction.D to 32,
        ControlAction.SPACE to 62, ControlAction.SHIFT to 59, ControlAction.CTRL to 113, ControlAction.ALT to 57,
        ControlAction.TAB to 61, ControlAction.ESC to 111, ControlAction.ENTER to 66,
        ControlAction.E to 33, ControlAction.Q to 45, ControlAction.R to 46, ControlAction.F to 34,
        ControlAction.N0 to 7, ControlAction.N1 to 8, ControlAction.N2 to 9, ControlAction.N3 to 10,
        ControlAction.N4 to 11, ControlAction.N5 to 12, ControlAction.N6 to 13, ControlAction.N7 to 14,
        ControlAction.N8 to 15, ControlAction.N9 to 16,
    )

    /** null = a ação não tem tecla fixa (CUSTOM1..4 usam a tecla escolhida no perfil). */
    fun of(action: ControlAction): Int? = map[action]

    /** Teclas que o usuário pode atribuir a um botão CUSTOM: nome -> keycode. */
    fun customChoices(): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        ('A'..'Z').forEachIndexed { i, c -> out += c.toString() to 29 + i }
        ('0'..'9').forEachIndexed { i, c -> out += c.toString() to 7 + i }
        for (n in 1..12) out += "F$n" to 130 + n
        out += "↑" to 19
        out += "↓" to 20
        out += "←" to 21
        out += "→" to 22
        return out
    }

    fun nameOf(code: Int): String = customChoices().firstOrNull { it.second == code }?.first ?: "#$code"
}
