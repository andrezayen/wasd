package com.wasdoverlay.ui

import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.wasdoverlay.BuildConfig
import com.wasdoverlay.R
import com.wasdoverlay.control.AppRuntime
import com.wasdoverlay.input.InputAccessibilityService
import com.wasdoverlay.model.Orientation
import com.wasdoverlay.storage.AppSettings
import com.wasdoverlay.storage.ProfileStore
import com.wasdoverlay.util.Screen
import com.wasdoverlay.util.Ui

class DiagnosticsActivity : AppCompatActivity() {

    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val (sv, col) = Ui.scrollColumn(this)
        setContentView(sv)
        Ui.applyInsets(sv)
        col.addView(Ui.title(this, getString(R.string.diag_title)))
        info = Ui.body(this, "").also { it.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        col.addView(info)
        col.addView(Ui.button(this, getString(R.string.btn_refresh)) { render() })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val ok = getString(R.string.ok_word)
        val err = getString(R.string.error_word)
        val orientation = Screen.orientation(this)
        val orientationName = getString(if (orientation == Orientation.PORTRAIT) R.string.orientation_portrait else R.string.orientation_landscape)
        val profile = ProfileStore(this).resolveActive(orientation, getString(R.string.default_profile_name))
        val service = InputAccessibilityService.instance
        info.text = listOf(
            getString(R.string.diag_overlay, if (Settings.canDrawOverlays(this)) ok else err),
            getString(R.string.diag_service, if (service != null) ok else err),
            getString(R.string.diag_backend, if (service?.engine != null) ok else getString(R.string.unavailable_word)),
            getString(R.string.diag_mode, AppSettings(this).inputMode),
            getString(R.string.diag_privileged, if (AppRuntime.privilegedActive) AppRuntime.privilegedSource else getString(R.string.unavailable_word)),
            getString(R.string.diag_cancels, AppRuntime.gestureCancels.get()),
            getString(R.string.diag_state, AppRuntime.state.state.name),
            getString(R.string.diag_profile, profile.name),
            getString(R.string.diag_orientation, orientationName),
            getString(R.string.diag_android, Build.VERSION.RELEASE, Build.VERSION.SDK_INT),
            getString(R.string.diag_app, BuildConfig.VERSION_NAME),
            getString(R.string.diag_fg, InputAccessibilityService.foregroundPackage ?: getString(R.string.none_word)),
        ).joinToString("\n\n")
    }
}
