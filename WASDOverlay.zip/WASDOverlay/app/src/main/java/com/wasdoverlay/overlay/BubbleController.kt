package com.wasdoverlay.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import com.wasdoverlay.util.Screen

/** Janela pequena do botão flutuante (separada do overlay de controles). */
class BubbleController(
    private val context: Context,
    private val onToggle: () -> Unit,
    private val onEdit: () -> Unit,
    private val onSwitch: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private var view: BubbleView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var lastX: Int? = null
    private var lastY: Int? = null

    fun show(controlsHidden: Boolean) {
        view?.let { it.controlsHidden = controlsHidden; return }
        val s = Screen.size(context)
        val d = context.resources.displayMetrics.density
        val v = BubbleView(context, onToggle, onEdit, onSwitch, onStop, onResize = { resize() }, onDrag = { dx, dy -> drag(dx, dy) })
        v.controlsHidden = controlsHidden
        val params = WindowManager.LayoutParams(
            v.desiredWidth(), v.desiredHeight(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (lastX ?: (s.width - v.desiredWidth() - (12 * d).toInt())).coerceIn(0, (s.width - v.desiredWidth()).coerceAtLeast(0))
            y = (lastY ?: (12 * d).toInt()).coerceIn(0, (s.height - v.desiredHeight()).coerceAtLeast(0))
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            windowManager.addView(v, params)
            view = v
            lp = params
        } catch (_: RuntimeException) {
            // sem permissão: o botão flutuante simplesmente não aparece
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        lp = null
        try {
            windowManager.removeViewImmediate(v)
        } catch (_: IllegalArgumentException) {
            // já removida
        }
    }

    private fun resize() {
        val v = view ?: return
        val p = lp ?: return
        val s = Screen.size(context)
        p.width = v.desiredWidth()
        p.height = v.desiredHeight()
        p.x = p.x.coerceIn(0, (s.width - p.width).coerceAtLeast(0))
        update(v, p)
    }

    private fun drag(dx: Float, dy: Float) {
        val v = view ?: return
        val p = lp ?: return
        val s = Screen.size(context)
        p.x = (p.x + dx.toInt()).coerceIn(0, (s.width - p.width).coerceAtLeast(0))
        p.y = (p.y + dy.toInt()).coerceIn(0, (s.height - p.height).coerceAtLeast(0))
        lastX = p.x
        lastY = p.y
        update(v, p)
    }

    private fun update(v: BubbleView, p: WindowManager.LayoutParams) {
        try {
            windowManager.updateViewLayout(v, p)
        } catch (_: IllegalArgumentException) {
            // view já removida
        }
    }
}
