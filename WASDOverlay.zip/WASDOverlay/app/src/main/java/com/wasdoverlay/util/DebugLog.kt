package com.wasdoverlay.util

import android.util.Log
import com.wasdoverlay.BuildConfig

/** Log só em debug e só se ligado nas configurações. Nunca registre texto digitado, dados pessoais ou conteúdo de outros apps. */
object DebugLog {
    private const val TAG = "WasdOverlay"

    @Volatile
    var enabled: Boolean = BuildConfig.DEBUG

    fun d(message: String) {
        if (BuildConfig.DEBUG && enabled) Log.d(TAG, message)
    }
}
