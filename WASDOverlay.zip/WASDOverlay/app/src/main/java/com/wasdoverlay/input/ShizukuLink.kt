package com.wasdoverlay.input

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.RemoteException
import com.wasdoverlay.BuildConfig
import com.wasdoverlay.control.AppRuntime
import com.wasdoverlay.shizuku.IInjectorService
import com.wasdoverlay.shizuku.InjectorUserService
import rikka.shizuku.Shizuku

/**
 * Acesso privilegiado SEM root via Shizuku (o usuário instala o app Shizuku e o inicia por
 * depuração sem fio ou root). Executa [InjectorUserService] com identidade de shell, que tem
 * INJECT_EVENTS. Se o Shizuku não estiver rodando ou autorizado, [isReady] é false.
 */
class ShizukuLink(private val context: Context) : InjectorLink {
    @Volatile private var service: IInjectorService? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IInjectorService.Stub.asInterface(binder) else null
            AppRuntime.privilegedActive = service != null
            if (service != null) AppRuntime.privilegedSource = "shizuku"
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            AppRuntime.privilegedActive = false
        }
    }

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(context.packageName, InjectorUserService::class.java.name))
            .daemon(false)
            .processNameSuffix("injector")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    override val isAlive: Boolean get() = service?.asBinder()?.isBinderAlive == true

    /** Shizuku rodando E este app autorizado. */
    fun isReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    override fun start() {
        if (!isReady()) return
        try {
            Shizuku.bindUserService(args, connection)
        } catch (_: Throwable) {
            service = null
        }
    }

    override fun send(line: String) {
        try {
            service?.command(line)
        } catch (_: RemoteException) {
            service = null
        }
    }

    override fun stop() {
        try { service?.command("RA"); service?.command("X") } catch (_: RemoteException) { }
        try { Shizuku.unbindUserService(args, connection, true) } catch (_: Throwable) { }
        service = null
        AppRuntime.privilegedActive = false
    }
}
