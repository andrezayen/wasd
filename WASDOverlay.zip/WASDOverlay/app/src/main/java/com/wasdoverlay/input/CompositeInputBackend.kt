package com.wasdoverlay.input

import com.wasdoverlay.model.ControlAction
import java.util.EnumSet

/**
 * Usa o backend root enquanto ele estiver vivo e suportar a ação; senão, cai para o fallback
 * (acessibilidade). Lembra qual backend recebeu cada "press" para soltar no mesmo.
 */
class CompositeInputBackend(
    private val primary: InputBackend,
    private val supports: (ControlAction) -> Boolean,
    private val fallback: InputBackend,
) : InputBackend {

    private val onPrimary: MutableSet<ControlAction> = EnumSet.noneOf(ControlAction::class.java)

    override val isAvailable: Boolean get() = primary.isAvailable || fallback.isAvailable

    override fun press(action: ControlAction) {
        if (primary.isAvailable && supports(action)) {
            onPrimary.add(action)
            primary.press(action)
        } else {
            fallback.press(action)
        }
    }

    override fun release(action: ControlAction) {
        if (onPrimary.remove(action)) primary.release(action) else fallback.release(action)
    }

    override fun releaseAll() {
        onPrimary.clear()
        try {
            primary.releaseAll()
        } finally {
            fallback.releaseAll()
        }
    }
}
